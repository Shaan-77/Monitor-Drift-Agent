# ZeroUI Beta ER Demo Testing Scripts — v12.4

This pack is repository-only. Policy values are dynamically loaded from tenant PostgreSQL on every run.

## Authority chain

active tenant
-> exactly one active runtime generation
-> exact ER member
-> pinned tenant_threshold_version_id
-> Published threshold version
-> effective relational values/config
-> governed rules

There are no hardcoded policy threshold values and no latest-published/local/default threshold fallback.

## First step in a new repository

Run the OS-specific `00-Prepare-DemoRepo` wrapper, or use the outer cross-platform launcher with `-Action Setup`, before running individual scenarios.

Prepare performs read-only policy validation and adds only the demo distribution/pack path to that repository's local Git exclude file. It does not modify the ZeroUI Extension or VSIX.

## Actions

Allow
- rolls package-owned demo evidence back ER-by-ER using the active DB policy;
- does not automatically rewrite unknown real application violations.

Warn
- dynamically examines active Beta ER policies;
- simulates WARN only where the active policy defines `human_review_required`;
- ERs without an active WARN lane are skipped;
- an active WARN lane without a safe deterministic repo simulator fails closed.

Block
- dynamically examines active Beta ER policies;
- simulates active `deny` lanes only;
- threshold crossings, regexes, file locations, dependency severity boundaries, test artifacts and effective values come from the DB;
- unsupported active hard-block semantics fail closed.


## Automatic ALLOW lifecycle cleanup

`98-Restore-Original` is no longer required between normal demo scenarios once ALLOW has been verified.

- After an individual ALLOW scenario: run **Check Current Context** and verify ALLOW, then start the next scenario directly. The next scenario automatically restores the previous ALLOW lifecycle first.
- After WARN/DENY: run the matching rollback, run **Check Current Context** and verify recovery to ALLOW, then start the next scenario directly. The recovered ALLOW lifecycle is automatically restored first.
- WARN/DENY evidence is never auto-restored before rollback; those states remain fail-closed.
- `98-Restore-Original` remains available when you want immediate cleanup or you are ending the demo without starting another scenario.

This preserves the product-verification boundary: the pack does not claim the final governed decision and does not erase ALLOW evidence before you have an opportunity to run **Check Current Context**.

## Repository portability

The target repository is discovered with Git, not by a hardcoded path or repository name. The lifecycle supports repositories whose path contains spaces and uses `git rev-parse --git-path` for repository-internal state so Git worktrees are handled correctly.

Runtime configuration precedence is deterministic and non-interactive:
1. process environment (`ZEROUI_TENANT_DB_URL`, `ZEROUI_TENANT_ID` / `ZEROUI_DEMO_TENANT_ID`);
2. supported target-repository keys in `.vscode/settings.json`, `.cursor/settings.json`, or `.zeroui/runtime.json`;
3. packaged local-demo defaults: tenant DB `localhost:5433/zeroui_tenant_pg` and tenant `T/AMAZON/001`.

This means a clean target Git repository does not require manual tenant-ID or tenant-DB environment setup for the standard local demo. Environment/repository configuration still overrides the packaged defaults for other installations. The packaged DB connection default is routing/configuration only; ER threshold values are never packaged and are still loaded dynamically from the active tenant PostgreSQL runtime generation.

The PostgreSQL URL must resolve host, user and database (database in the URL path or `?dbname=`). `psql` is invoked with `-w`; bad/unreachable credentials fail closed instead of opening an interactive password prompt.

## Safety boundary

The pack does not modify/build/install/uninstall/reload the ZeroUI Extension or VSIX. The policy resolver performs no DB writes. The installed ZeroUI product remains authoritative for the final governed decision; run **Check Current Context** after simulation.

## v12.4 prepare reliability
Prepare now reconciles stale managed ignore blocks from earlier pack versions and verifies the current pack is actually ignored before reporting success.
