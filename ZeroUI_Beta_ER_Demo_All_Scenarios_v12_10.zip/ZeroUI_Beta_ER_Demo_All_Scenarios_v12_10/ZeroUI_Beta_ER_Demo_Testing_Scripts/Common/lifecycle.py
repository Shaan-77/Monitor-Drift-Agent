#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

PACK_ROOT = Path(__file__).resolve().parents[1]
STATE_DIR = PACK_ROOT / ".state"
STATE_FILE = STATE_DIR / "active.json"
IGNORE_BEGIN = "# BEGIN ZEROUI_BETA_ER_DEMO_DB_DYNAMIC"
IGNORE_END = "# END ZEROUI_BETA_ER_DEMO_DB_DYNAMIC"
ENGINE = PACK_ROOT / "Common" / "scenario_engine.py"
PREPARE_META_FILE = PACK_ROOT / ".prepare-state.json"


class LifecycleError(RuntimeError):
    pass


def run(cmd: list[str], *, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        detail = (p.stderr or p.stdout or "").strip()
        raise LifecycleError(f"COMMAND_FAILED: {' '.join(cmd)}: {detail}")
    return p


def git(repo: Path, *args: str, check: bool = True) -> str:
    return (run(["git", "-C", str(repo), *args], check=check).stdout or "").strip()


def repo_root() -> Path:
    p = run(["git", "-C", str(PACK_ROOT), "rev-parse", "--show-toplevel"], check=False)
    if p.returncode != 0 or not (p.stdout or "").strip():
        raise LifecycleError("PACK_NOT_INSIDE_GIT_REPOSITORY")
    return Path(p.stdout.strip()).resolve()


def pack_rel(repo: Path) -> str:
    try:
        return PACK_ROOT.resolve().relative_to(repo.resolve()).as_posix()
    except ValueError as exc:
        raise LifecycleError("PACK_NOT_INSIDE_TARGET_REPOSITORY") from exc


def _distribution_root_candidates(repo: Path) -> list[Path]:
    candidates: list[Path] = []
    parent = PACK_ROOT.parent.resolve()
    if (parent / "RELEASE_MANIFEST.json").is_file() and (parent / "START_HERE.txt").is_file():
        candidates.append(parent)
    raw = (os.environ.get("ZEROUI_DEMO_DISTRIBUTION_ROOT") or "").strip()
    if raw:
        candidate = Path(raw).resolve()
        if (candidate / "RELEASE_MANIFEST.json").is_file() and (candidate / "START_HERE.txt").is_file():
            candidates.append(candidate)
    out: list[Path] = []
    for candidate in candidates:
        try:
            rel = candidate.relative_to(repo.resolve())
        except ValueError:
            continue
        if str(rel) in {"", "."}:
            continue
        if candidate not in out:
            out.append(candidate)
    return out


def ignore_rel_paths(repo: Path) -> list[str]:
    paths = {pack_rel(repo).strip("/")}
    for root in _distribution_root_candidates(repo):
        paths.add(root.relative_to(repo.resolve()).as_posix().strip("/"))
    return sorted(x for x in paths if x)


def git_dir(repo: Path) -> Path:
    raw = git(repo, "rev-parse", "--git-dir")
    p = Path(raw)
    return p if p.is_absolute() else (repo / p).resolve()


def git_path(repo: Path, relative: str) -> Path:
    raw = git(repo, "rev-parse", "--git-path", relative)
    p = Path(raw)
    return p if p.is_absolute() else (repo / p).resolve()


def _sha256_text(value: str) -> str:
    import hashlib
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _gitignore_status(repo: Path) -> str:
    return git(repo, "status", "--porcelain=v1", "--untracked-files=all", "--", ".gitignore", check=False)


def root_gitignore_entries(repo: Path) -> list[str]:
    """Return exact repo-root .gitignore entries for the active distribution.

    For the combined ZIP this is the outer distribution folder (for example
    /ZeroUI_Beta_ER_Demo_All_Scenarios_v12_10/). For the embedded one-shot pack,
    where no outer distribution exists in the repo, fall back to the pack folder.
    """
    roots = _distribution_root_candidates(repo)
    rels: set[str] = set()
    for root in roots:
        rels.add(root.relative_to(repo.resolve()).as_posix().strip("/"))
    if not rels:
        rels.add(pack_rel(repo).strip("/"))
    return [f"/{rel}/" for rel in sorted(x for x in rels if x)]


def _write_prepare_meta(meta: dict) -> None:
    PREPARE_META_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = PREPARE_META_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(PREPARE_META_FILE)


def _load_prepare_meta() -> dict | None:
    if not PREPARE_META_FILE.exists():
        return None
    try:
        value = json.loads(PREPARE_META_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None
    return value if isinstance(value, dict) else None


def ensure_root_gitignore(repo: Path) -> tuple[Path, list[str], bool, bool]:
    """Ensure the current distribution is explicitly listed in repo-root .gitignore.

    Existing content is preserved. If .gitignore does not exist it is created.
    Metadata is recorded so the pack can treat only its own controlled .gitignore
    delta as clean during simulations and can safely undo it during explicit cleanup.
    """
    path = repo / ".gitignore"
    existed_before = path.exists()
    original = path.read_text(encoding="utf-8") if existed_before else ""
    pre_status = _gitignore_status(repo)
    entries = root_gitignore_entries(repo)
    present = {line.strip() for line in original.splitlines()}
    additions = [entry for entry in entries if entry not in present]

    updated = original
    if additions:
        if updated and not updated.endswith("\n"):
            updated += "\n"
        updated += "\n".join(additions) + "\n"
        path.write_text(updated, encoding="utf-8")
    elif not existed_before:
        # Defensive: root_gitignore_entries is non-empty, so this path should only
        # be reachable if future logic changes. Still satisfy the create contract.
        path.write_text("", encoding="utf-8")
        updated = ""

    actual = path.read_text(encoding="utf-8")
    actual_lines = {line.strip() for line in actual.splitlines()}
    missing = [entry for entry in entries if entry not in actual_lines]
    if missing:
        raise LifecycleError(
            "ROOT_GITIGNORE_RECONCILIATION_FAILED: missing " + ",".join(missing)
        )

    changed = actual != original or not existed_before
    # We may safely whitelist the delta only when .gitignore was clean/nonexistent
    # before Prepare. Pre-existing user changes remain visible to the clean-repo guard.
    managed_delta = bool(changed and not pre_status.strip())
    _write_prepare_meta({
        "schema_version": "1.0.0",
        "repo_root": str(repo.resolve()),
        "gitignore_path": ".gitignore",
        "entries": entries,
        "existed_before": existed_before,
        "original_text": original if managed_delta else None,
        "original_sha256": _sha256_text(original),
        "expected_sha256": _sha256_text(actual),
        "managed_delta": managed_delta,
        "pre_status": pre_status,
    })
    return path, entries, changed, managed_delta


def pack_owned_gitignore_delta_active(repo: Path) -> bool:
    meta = _load_prepare_meta()
    if not meta or not meta.get("managed_delta"):
        return False
    try:
        if Path(str(meta.get("repo_root") or "")).resolve() != repo.resolve():
            return False
    except Exception:
        return False
    path = repo / ".gitignore"
    if not path.exists():
        return False
    try:
        actual = path.read_text(encoding="utf-8")
    except Exception:
        return False
    return _sha256_text(actual) == str(meta.get("expected_sha256") or "")


def restore_pack_owned_gitignore_delta(repo: Path) -> str:
    """Undo only the exact .gitignore delta created by Prepare, when still unchanged."""
    meta = _load_prepare_meta()
    if not meta or not meta.get("managed_delta"):
        return "NO_MANAGED_DELTA"
    if not pack_owned_gitignore_delta_active(repo):
        return "SKIPPED_USER_MODIFIED"
    path = repo / ".gitignore"
    original = meta.get("original_text")
    if not isinstance(original, str):
        return "SKIPPED_METADATA_INVALID"
    if bool(meta.get("existed_before")):
        path.write_text(original, encoding="utf-8")
    else:
        path.unlink(missing_ok=True)
    PREPARE_META_FILE.unlink(missing_ok=True)
    return "RESTORED"


def prepared(repo: Path) -> bool:
    rel = (Path(pack_rel(repo)) / "README.md").as_posix()
    return run(["git", "-C", str(repo), "check-ignore", "-q", "--", rel], check=False).returncode == 0


def reconcile_managed_ignore_block(existing: str, desired_entries: list[str]) -> str:
    """Reconcile the repo-local managed ignore block without deleting prior pack entries.

    Older demo-pack versions use the same markers. A previous implementation only
    wrote the block when the begin marker was absent, which meant extracting a new
    version beside an older prepared version could print PREPARED=YES while the new
    pack itself was not ignored. This routine merges the current pack entries into
    the existing managed block and rewrites exactly one balanced block.
    """
    lines = existing.splitlines()
    outside: list[str] = []
    managed: list[str] = []
    inside = False
    begin_count = 0
    end_count = 0

    for line in lines:
        if line == IGNORE_BEGIN:
            if inside:
                raise LifecycleError("GIT_EXCLUDE_MANAGED_BLOCK_INVALID: nested begin marker")
            inside = True
            begin_count += 1
            continue
        if line == IGNORE_END:
            if not inside:
                raise LifecycleError("GIT_EXCLUDE_MANAGED_BLOCK_INVALID: end marker without begin")
            inside = False
            end_count += 1
            continue
        if inside:
            value = line.strip()
            if value:
                managed.append(value)
        else:
            outside.append(line)

    if inside or begin_count != end_count:
        raise LifecycleError("GIT_EXCLUDE_MANAGED_BLOCK_INVALID: unbalanced markers")

    merged: list[str] = []
    seen: set[str] = set()
    for value in [*managed, *desired_entries]:
        value = value.strip()
        if not value or value in seen:
            continue
        seen.add(value)
        merged.append(value)

    while outside and outside[-1] == "":
        outside.pop()

    out = list(outside)
    if out:
        out.append("")
    out.append(IGNORE_BEGIN)
    out.extend(merged)
    out.append(IGNORE_END)
    return "\n".join(out) + "\n"


def prepare() -> None:
    repo = repo_root()

    # User-visible root .gitignore contract: create if absent and add the exact
    # current distribution folder entry without deleting existing ignore rules.
    gitignore_path, gitignore_entries, gitignore_changed, gitignore_managed = ensure_root_gitignore(repo)

    # Preserve the existing repo-local info/exclude behavior as a second safety net.
    exclude = git_path(repo, "info/exclude")
    exclude.parent.mkdir(parents=True, exist_ok=True)
    existing = exclude.read_text(encoding="utf-8") if exclude.exists() else ""
    desired_entries = [f"/{rel}/" for rel in ignore_rel_paths(repo)]
    reconciled = reconcile_managed_ignore_block(existing, desired_entries)
    if reconciled != existing:
        exclude.write_text(reconciled, encoding="utf-8")

    # Do not claim preparation success unless Git confirms this exact pack is ignored.
    if not prepared(repo):
        raise LifecycleError("PACK_GIT_IGNORE_RECONCILIATION_FAILED: current demo pack is not ignored")

    engine(["prepare", "--repo", str(repo), "--er", "ER-073", "--token", "prepare"], repo=repo)
    print("DEMO_REPO_PREPARED=YES")
    print(f"REPO_ROOT={repo}")
    print("RUNTIME_CONFIG_SOURCE=PROCESS_ENV_OR_REPO_CONFIG_OR_PACK_DEFAULT")
    print("MANUAL_DB_ENV_REQUIRED=NO")
    print("THRESHOLD_MODE=DB_DYNAMIC_ONLY")
    print("DB_WRITES=NO")
    print("PACK_GIT_IGNORED=YES")
    print("PACK_GIT_IGNORE_RECONCILED=YES")
    print("ROOT_GITIGNORE_ENSURED=YES")
    print(f"ROOT_GITIGNORE_FILE={gitignore_path.relative_to(repo).as_posix()}")
    for entry in gitignore_entries:
        print(f"ROOT_GITIGNORE_ENTRY={entry}")
    print(f"ROOT_GITIGNORE_CHANGED={'YES' if gitignore_changed else 'NO'}")
    print(f"ROOT_GITIGNORE_PACK_MANAGED_DELTA={'YES' if gitignore_managed else 'NO'}")


def load_state() -> dict | None:
    if not STATE_FILE.exists():
        return None
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))


def save_state(state: dict) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(STATE_FILE)


def repo_dirty(repo: Path) -> bool:
    status = run(["git", "-C", str(repo), "status", "--porcelain=v1", "--untracked-files=all"]).stdout or ""
    lines = status.splitlines()
    allow_gitignore = pack_owned_gitignore_delta_active(repo)
    for line in lines:
        if not line.strip():
            continue
        path_part = line[3:].strip() if len(line) >= 3 else ""
        if " -> " in path_part:
            path_part = path_part.split(" -> ")[-1].strip()
        if allow_gitignore and path_part.replace("\\", "/") == ".gitignore":
            continue
        return True
    return False


def changed_paths(repo: Path) -> list[str]:
    out: set[str] = set()
    for args in [
        ("diff", "--name-only", "HEAD"),
        ("diff", "--cached", "--name-only"),
        ("ls-files", "--others", "--exclude-standard"),
    ]:
        for line in git(repo, *args, check=False).splitlines():
            rel = line.strip().replace("\\", "/")
            if rel:
                out.add(rel)
    if pack_owned_gitignore_delta_active(repo):
        out.discard(".gitignore")
    return sorted(out)


def original_snapshot(repo: Path) -> dict:
    branch = git(repo, "symbolic-ref", "--quiet", "--short", "HEAD", check=False)
    commit = git(repo, "rev-parse", "HEAD")
    return {
        "original_branch": branch,
        "original_detached": not bool(branch),
        "original_commit": commit,
    }


def engine(args: list[str], *, repo: Path | None = None) -> str:
    env = os.environ.copy()
    if repo:
        env["ZEROUI_DEMO_REPO"] = str(repo)
    p = subprocess.run([sys.executable, str(ENGINE), *args],
                       cwd=str(repo) if repo else None, env=env,
                       text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.stdout:
        print(p.stdout, end="" if p.stdout.endswith("\n") else "\n")
    if p.returncode != 0:
        raise LifecycleError((p.stderr or p.stdout or "SCENARIO_ENGINE_FAILED").strip())
    return p.stdout or ""


def parse_kv(output: str, key: str) -> str:
    prefix = key + "="
    vals = [line[len(prefix):] for line in output.splitlines() if line.startswith(prefix)]
    if len(vals) != 1 or not vals[0].strip():
        raise LifecycleError(f"ENGINE_OUTPUT_MISSING: {key}")
    return vals[0].strip()


def dynamic_branch(mode: str, token: str) -> str:
    return parse_kv(engine(["branch", "--mode", mode, "--token", token]), "BRANCH_NAME")


def path_is_tracked_at_head(repo: Path, rel: str) -> bool:
    return run(["git", "-C", str(repo), "cat-file", "-e", f"HEAD:{rel}"], check=False).returncode == 0


def remove_untracked_path(repo: Path, rel: str) -> None:
    target = (repo / rel).resolve()
    try:
        target.relative_to(repo.resolve())
    except ValueError as exc:
        raise LifecycleError(f"RECORDED_PATH_OUTSIDE_REPO: {rel}") from exc
    if target.is_symlink() or target.is_file():
        target.unlink(missing_ok=True)
    elif target.is_dir():
        shutil.rmtree(target)
    parent = target.parent
    while parent != repo and parent.exists():
        try:
            parent.rmdir()
        except OSError:
            break
        parent = parent.parent


def clean_recorded_paths(repo: Path, paths: list[str]) -> None:
    # Only paths recorded by the demo are touched; no git clean/reset is used.
    for rel in sorted(set(paths), key=lambda x: (x.count("/"), x), reverse=True):
        if path_is_tracked_at_head(repo, rel):
            git(repo, "restore", "--source=HEAD", "--staged", "--worktree", "--", rel, check=False)
        else:
            remove_untracked_path(repo, rel)


def branch_exists(repo: Path, branch: str) -> bool:
    return run(["git", "-C", str(repo), "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"], check=False).returncode == 0


def switch_to_recovery_branch(repo: Path, desired: str) -> str:
    current = git(repo, "branch", "--show-current", check=False)
    if current == desired:
        return desired
    if branch_exists(repo, desired):
        raise LifecycleError(f"RECOVERY_BRANCH_ALREADY_EXISTS: {desired}")
    if current:
        git(repo, "branch", "-m", desired)
    else:
        git(repo, "switch", "-c", desired)
    return desired


def restore_original_internal(state: dict, *, remove_state: bool) -> None:
    repo = Path(state["repo_root"])
    clean_recorded_paths(repo, list(state.get("recovery_changed_paths") or []))
    clean_recorded_paths(repo, list(state.get("demo_changed_paths") or []))
    current = git(repo, "branch", "--show-current", check=False)
    if state.get("original_detached"):
        git(repo, "switch", "--detach", state["original_commit"])
    else:
        git(repo, "switch", state["original_branch"])
    for branch in {current, state.get("demo_branch", ""), state.get("recovery_branch", "")}:
        if branch and branch != state.get("original_branch"):
            git(repo, "branch", "-D", branch, check=False)
    if remove_state and STATE_DIR.exists():
        shutil.rmtree(STATE_DIR)
    print("ORIGINAL_SNAPSHOT_RESTORED=YES")


def auto_finalize_previous_allow_lifecycle(repo: Path) -> str:
    """Restore only a previously completed ALLOW-side lifecycle before a new scenario.

    Safe automatic finalization is intentionally limited to:
    - a rollback that already reached recovered_allow; or
    - an individual scenario whose expected decision is ALLOW.

    WARN/DENY simulations remain fail-closed until their matching rollback is run.
    The caller starting a new scenario is treated as the explicit signal that any
    manual Check Current Context verification for the previous ALLOW state is done.
    """
    state = load_state()
    if not state:
        return "NONE"

    state_repo_raw = str(state.get("repo_root") or "").strip()
    if not state_repo_raw:
        raise LifecycleError("ACTIVE_DEMO_STATE_INVALID: repo_root missing.")
    state_repo = Path(state_repo_raw).resolve()
    if state_repo != repo.resolve():
        raise LifecycleError("ACTIVE_DEMO_REPO_MISMATCH: saved lifecycle belongs to another repository.")

    phase = str(state.get("phase") or "").strip()
    expected = str(state.get("expected_decision") or "").strip().upper()

    if phase == "recovered_allow":
        restore_original_internal(state, remove_state=True)
        print("PREVIOUS_RECOVERED_ALLOW_AUTO_RESTORED=YES")
        return "RECOVERED_ALLOW"

    if phase == "simulated" and expected == "ALLOW":
        restore_original_internal(state, remove_state=True)
        print("PREVIOUS_ALLOW_SCENARIO_AUTO_RESTORED=YES")
        return "SIMULATED_ALLOW"

    raise LifecycleError(
        "ACTIVE_DEMO_EXISTS: WARN/DENY simulations must be rolled back first; "
        "98-Restore-Original remains available for explicit immediate cleanup."
    )


def simulate(er: str, scenario: str, case_type: str, expected_decision: str) -> None:
    repo = repo_root()
    if not prepared(repo):
        raise LifecycleError("RUN_PREPARE_FIRST: execute 00-Prepare-DemoRepo for this pack.")
    auto_finalize_previous_allow_lifecycle(repo)
    if repo_dirty(repo):
        raise LifecycleError("TARGET_REPO_NOT_CLEAN: commit/stash your own changes before starting a demo.")

    token = uuid.uuid4().hex[:8]
    state = {
        "schema_version": "8.0.0",
        "phase": "starting",
        "repo_root": str(repo),
        "er_id": er,
        "scenario_id": scenario,
        "case_type": case_type,
        "expected_decision": expected_decision,
        "token": token,
        **original_snapshot(repo),
    }
    save_state(state)
    try:
        branch_mode = "noncompliant" if (er == "ER-074" and scenario == "NONCOMPLIANT-BRANCH-DENY") else "compliant"
        branch = dynamic_branch(branch_mode, token)
        if branch_exists(repo, branch):
            raise LifecycleError(f"DEMO_BRANCH_ALREADY_EXISTS: {branch}")
        git(repo, "switch", "-c", branch)
        state["demo_branch"] = branch
        save_state(state)

        # DB policy preflight. It performs read-only validation and never writes thresholds locally.
        engine(["prepare", "--repo", str(repo), "--er", er, "--token", token], repo=repo)
        impact = engine(["apply", "--repo", str(repo), "--er", er, "--scenario", scenario, "--token", token], repo=repo)
        state["demo_changed_paths"] = changed_paths(repo)
        state["phase"] = "simulated"
        state["impact"] = impact
        save_state(state)
    except Exception:
        try:
            state["demo_changed_paths"] = changed_paths(repo)
            save_state(state)
            restore_original_internal(state, remove_state=True)
        except Exception:
            pass
        raise

    print("DEMO_ACTIVATED=YES")
    print(f"ER_ID={er}")
    print(f"CASE_TYPE={case_type}")
    print(f"SCENARIO_ID={scenario}")
    print(f"EXPECTED_DECISION={expected_decision}")
    print("THRESHOLDS_HARDCODED=NO")
    print("THRESHOLD_AUTHORITY=tenant_postgresql")
    print("DB_POLICY_REQUERIED_FOR_SIMULATION=YES")
    if str(expected_decision).strip().upper() == "ALLOW":
        print("NEXT_ACTION=Run ZeroUI Check Current Context and verify ALLOW; then run the next scenario directly. This ALLOW lifecycle auto-restores before the next scenario starts.")
    else:
        print("NEXT_ACTION=Run ZeroUI Check Current Context and verify the expected decision.")


def rollback(er: str, scenario: str, expected_decision: str) -> None:
    state = load_state()
    if not state:
        if er != "ER-073":
            raise LifecycleError("No active demo lifecycle exists.")
        repo = repo_root()
        token = "stateless-" + uuid.uuid4().hex[:8]
        engine(
            ["recover", "--repo", str(repo), "--er", er, "--token", token],
            repo=repo,
        )
        print("ROLLBACK_REMEDIATION_COMPLETE=YES")
        print("ROLLBACK_MODE=STATELESS")
        print("ACTIVE_DEMO_LIFECYCLE=NO")
        print("ER_ID=ER-073")
        print(f"SCENARIO_ID={scenario}")
        print(f"PRIOR_EXPECTED_DECISION={expected_decision}")
        print("TARGET_RECOVERY_DECISION=ALLOW")
        print("ER073_TRIGGER_AUTHORITY=workspace_source_scan")
        print("ER073_JUNIT_TRIGGER_AUTHORITY=NO")
        print("ER073_PASSING_RECOVERY_FIXTURE=test_zeroui_er073_demo.py")
        print("DB_POLICY_REQUERIED_FOR_ROLLBACK=YES")
        print("THRESHOLDS_HARDCODED=NO")
        print("THRESHOLD_AUTHORITY=tenant_postgresql")
        print("FINAL_VERIFICATION=Run the existing ZeroUI Check Current Context manually.")
        return
    if (state.get("er_id"), state.get("scenario_id"), state.get("expected_decision")) != (er, scenario, expected_decision):
        raise LifecycleError(
            f"ROLLBACK_MISMATCH: active={state.get('er_id')}/{state.get('scenario_id')}/{state.get('expected_decision')}"
        )
    if state.get("phase") == "recovered_allow":
        print("ROLLBACK_REMEDIATION_COMPLETE=YES")
        print("ROLLBACK_NOOP=YES")
        print("ALREADY_RECOVERED=YES")
        print("NEXT_ACTION=After validating ALLOW, run the next scenario directly; previous ALLOW lifecycle will auto-restore. 98-Restore-Original remains optional for immediate/final cleanup.")
        return
    if state.get("phase") != "simulated":
        raise LifecycleError(f"ROLLBACK_PHASE_INVALID: {state.get('phase')}")

    repo = Path(state["repo_root"])
    clean_recorded_paths(repo, list(state.get("demo_changed_paths") or []))
    if repo_dirty(repo):
        raise LifecycleError("ROLLBACK_SAFETY_STOP: repository contains changes not recorded by the demo.")

    # Requery current ER-074 DB policy for a compliant recovery branch.
    recovery = dynamic_branch("compliant", state["token"] + "r")
    recovery = switch_to_recovery_branch(repo, recovery)

    # Requery the target ER DB policy again. Saved threshold values are never reused.
    engine(["recover", "--repo", str(repo), "--er", er, "--token", state["token"]], repo=repo)
    state["recovery_changed_paths"] = changed_paths(repo)
    state["phase"] = "recovered_allow"
    state["recovery_branch"] = recovery
    save_state(state)

    print("ROLLBACK_REMEDIATION_COMPLETE=YES")
    print(f"ER_ID={er}")
    print(f"SCENARIO_ID={scenario}")
    print(f"SIMULATED_DECISION={expected_decision}")
    print("TARGET_RECOVERY_DECISION=ALLOW")
    print(f"RECOVERY_BRANCH={recovery}")
    print("DB_POLICY_REQUERIED_FOR_ROLLBACK=YES")
    print("THRESHOLDS_HARDCODED=NO")
    print("THRESHOLD_AUTHORITY=tenant_postgresql")
    if er == "ER-073":
        print("ER073_TRIGGER_AUTHORITY=workspace_source_scan")
        print("ER073_JUNIT_TRIGGER_AUTHORITY=NO")
        print("FINAL_VERIFICATION=Run the existing ZeroUI Check Current Context manually; after ALLOW validation, the next scenario auto-restores this lifecycle. 98-Restore-Original remains optional for immediate/final cleanup.")
    else:
        print("NEXT_ACTION=Run ZeroUI Check Current Context; after ALLOW validation, run the next scenario directly. Previous recovery auto-restores before it starts.")


def restore() -> None:
    state = load_state()
    if not state:
        raise LifecycleError("No saved demo lifecycle exists.")
    restore_original_internal(state, remove_state=True)


def cleanup() -> None:
    if load_state():
        raise LifecycleError("ACTIVE_DEMO_EXISTS: run 98-Restore-Original before cleanup.")
    repo = repo_root()

    er073_fixture = repo / "test_zeroui_er073_demo.py"
    if er073_fixture.is_file():
        try:
            content = er073_fixture.read_text(encoding="utf-8")
        except Exception:
            content = ""
        tracked = run(
            ["git", "-C", str(repo), "ls-files", "--error-unmatch", "--", "test_zeroui_er073_demo.py"],
            check=False,
        ).returncode == 0
        if "# ZEROUI_ER073_DEMO_OWNED" in content and not tracked:
            er073_fixture.unlink()
            print("ER073_STATELESS_RECOVERY_FIXTURE_REMOVED=YES")
    gitignore_cleanup = restore_pack_owned_gitignore_delta(repo)
    print(f"ROOT_GITIGNORE_CLEANUP={gitignore_cleanup}")

    exclude = git_path(repo, "info/exclude")
    if not exclude.exists():
        print("DEMO_REPO_CLEANUP_COMPLETE=YES")
        return
    lines = exclude.read_text(encoding="utf-8").splitlines()
    out: list[str] = []
    inside = False
    for line in lines:
        if line == IGNORE_BEGIN:
            inside = True
            continue
        if line == IGNORE_END:
            inside = False
            continue
        if not inside:
            out.append(line)
    exclude.write_text("\n".join(out) + ("\n" if out else ""), encoding="utf-8")
    print("DEMO_REPO_CLEANUP_COMPLETE=YES")


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("prepare")
    p = sub.add_parser("simulate")
    p.add_argument("--er", required=True)
    p.add_argument("--scenario", required=True)
    p.add_argument("--case-type", required=True)
    p.add_argument("--expected-decision", required=True)
    p = sub.add_parser("rollback")
    p.add_argument("--er", required=True)
    p.add_argument("--scenario", required=True)
    p.add_argument("--expected-decision", required=True)
    sub.add_parser("restore")
    sub.add_parser("cleanup")
    args = parser.parse_args()
    try:
        if args.cmd == "prepare":
            prepare()
        elif args.cmd == "simulate":
            simulate(args.er, args.scenario, args.case_type, args.expected_decision)
        elif args.cmd == "rollback":
            rollback(args.er, args.scenario, args.expected_decision)
        elif args.cmd == "restore":
            restore()
        elif args.cmd == "cleanup":
            cleanup()
        return 0
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
