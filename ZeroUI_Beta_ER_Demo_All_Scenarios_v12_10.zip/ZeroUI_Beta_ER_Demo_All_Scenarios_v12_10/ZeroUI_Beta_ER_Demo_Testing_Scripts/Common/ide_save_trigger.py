#!/usr/bin/env python3
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


class IdeSaveTriggerError(RuntimeError):
    pass


def _vscode_cli_candidates() -> list[Path]:
    candidates: list[Path] = []
    for name in ("code", "code-insiders"):
        found = shutil.which(name)
        if found:
            candidates.append(Path(found))

    if os.name == "nt":
        vscode_cwd = (os.environ.get("VSCODE_CWD") or "").strip()
        local_appdata = (os.environ.get("LOCALAPPDATA") or "").strip()
        program_files = (os.environ.get("ProgramFiles") or "").strip()
        roots: list[Path] = []
        if vscode_cwd:
            roots.append(Path(vscode_cwd))
        if local_appdata:
            roots.extend([
                Path(local_appdata) / "Programs" / "Microsoft VS Code",
                Path(local_appdata) / "Programs" / "Microsoft VS Code Insiders",
            ])
        if program_files:
            roots.extend([
                Path(program_files) / "Microsoft VS Code",
                Path(program_files) / "Microsoft VS Code Insiders",
            ])
        for root in roots:
            candidates.extend([
                root / "bin" / "code.cmd",
                root / "bin" / "code-insiders.cmd",
                root / "Code.exe",
                root / "Code - Insiders.exe",
            ])
    elif sys.platform == "darwin":
        candidates.extend([
            Path("/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"),
            Path.home() / "Applications/Visual Studio Code.app/Contents/Resources/app/bin/code",
            Path("/Applications/Visual Studio Code - Insiders.app/Contents/Resources/app/bin/code-insiders"),
            Path.home() / "Applications/Visual Studio Code - Insiders.app/Contents/Resources/app/bin/code-insiders",
        ])

    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).lower() if os.name == "nt" else str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if candidate.exists() or shutil.which(str(candidate)):
            unique.append(candidate)
    return unique


def _open_in_vscode(target: Path) -> str:
    errors: list[str] = []
    for cli in _vscode_cli_candidates():
        try:
            args = [str(cli), "--reuse-window", str(target)]
            if os.name == "nt" and cli.suffix.lower() in {".cmd", ".bat"}:
                comspec = os.environ.get("COMSPEC") or shutil.which("cmd.exe") or "cmd.exe"
                proc = subprocess.run(
                    [comspec, "/d", "/s", "/c", subprocess.list2cmdline(args)],
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=15,
                )
            else:
                proc = subprocess.run(
                    args,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=15,
                )
            if proc.returncode == 0:
                return cli.name
            errors.append(proc.stderr.strip() or f"{cli}:exit={proc.returncode}")
        except Exception as exc:
            errors.append(f"{cli}:{exc}")

    if sys.platform == "darwin":
        for app in ("Visual Studio Code", "Visual Studio Code - Insiders"):
            try:
                proc = subprocess.run(
                    ["open", "-a", app, str(target)],
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=15,
                )
                if proc.returncode == 0:
                    return app
                errors.append(proc.stderr.strip() or f"open -a {app}:exit={proc.returncode}")
            except Exception as exc:
                errors.append(f"open -a {app}:{exc}")

    raise IdeSaveTriggerError(
        "unable to open generated ER-072 evidence in the active VS Code window; "
        + " | ".join(errors[-5:])
    )


def _send_windows_ctrl_s(repo: Path, target: Path) -> None:
    shell = shutil.which("pwsh") or shutil.which("powershell") or shutil.which("powershell.exe")
    if not shell:
        raise IdeSaveTriggerError("PowerShell is required to send Ctrl+S on Windows")

    script = r"""
$ErrorActionPreference = 'Stop'
$targetName = $env:ZEROUI_ER072_SAVE_TARGET_NAME
$repoHint = $env:ZEROUI_ER072_SAVE_REPO_HINT
$ws = New-Object -ComObject WScript.Shell
$all = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
    $_.MainWindowHandle -ne 0 -and $_.ProcessName -like 'Code*'
})
$candidates = @()
if ($targetName) { $candidates += @($all | Where-Object { $_.MainWindowTitle -like "*$targetName*" }) }
if ($repoHint) { $candidates += @($all | Where-Object { $_.MainWindowTitle -like "*$repoHint*" }) }
$candidates += $all
$seen = @{}
$activated = $false
foreach ($p in $candidates) {
    if ($seen.ContainsKey([string]$p.Id)) { continue }
    $seen[[string]$p.Id] = $true
    if ($ws.AppActivate($p.Id)) { $activated = $true; break }
}
if (-not $activated) { exit 41 }
Start-Sleep -Milliseconds 250
$ws.SendKeys('^s')
Start-Sleep -Milliseconds 250
"""
    env = os.environ.copy()
    env["ZEROUI_ER072_SAVE_TARGET_NAME"] = target.name
    env["ZEROUI_ER072_SAVE_REPO_HINT"] = repo.name
    proc = subprocess.run(
        [shell, "-NoProfile", "-NonInteractive", "-Command", script],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        timeout=15,
    )
    if proc.returncode != 0:
        raise IdeSaveTriggerError(
            f"Ctrl+S could not be delivered to VS Code (exit={proc.returncode}) {proc.stderr.strip()}"
        )


def _send_macos_cmd_s(cli_label: str) -> None:
    app = "Visual Studio Code - Insiders" if "insider" in cli_label.lower() else "Visual Studio Code"
    apple_script = (
        f'tell application "{app}" to activate\n'
        'delay 0.25\n'
        'tell application "System Events" to keystroke "s" using command down\n'
        'delay 0.25'
    )
    proc = subprocess.run(
        ["osascript", "-e", apple_script],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=15,
    )
    if proc.returncode != 0:
        raise IdeSaveTriggerError(
            "Cmd+S could not be delivered to VS Code. macOS may require Accessibility permission "
            f"for the terminal/osascript process. {proc.stderr.strip()}"
        )


def trigger_er072_vscode_save(repo: Path, target: Path) -> tuple[str, str]:
    repo = repo.resolve()
    target = target.resolve()
    try:
        rel = target.relative_to(repo).as_posix()
    except ValueError as exc:
        raise IdeSaveTriggerError(f"ER-072 save target is outside repository: {target}") from exc
    if not target.is_file():
        raise IdeSaveTriggerError(f"ER-072 save target is missing: {rel}")

    cli_label = _open_in_vscode(target)
    time.sleep(0.8)
    if os.name == "nt":
        _send_windows_ctrl_s(repo, target)
        mode = "CTRL_S"
    elif sys.platform == "darwin":
        _send_macos_cmd_s(cli_label)
        mode = "CMD_S"
    else:
        raise IdeSaveTriggerError(
            "automatic ER-072 save-event delivery is supported only on Windows and macOS"
        )

    # Production ER-072 save handling is debounced; wait beyond that window.
    time.sleep(1.2)
    return rel, mode
