# ZeroUI Beta ER Demo Testing Scripts — v12.11

This pack is repository-only. Policy values are dynamically loaded from tenant PostgreSQL on every run.

## Authority chain

active tenant
-> exactly one active runtime generation
-> exact ER member
-> pinned tenant_threshold_version_id
-> Published threshold version
-> effective relational values/config
-> governed rules

There are no hardcoded policy threshold values and no latest-published/local/default threshold fallback.

## First step in a new repository

Run the OS-specific `00-Prepare-DemoRepo` wrapper, or use the outer cross-platform launcher with `-Action Setup`, before running individual scenarios.

Prepare performs read-only policy validation and adds only the demo distribution/pack path to that repository's local Git exclude file. It does not modify the ZeroUI Extension or VSIX.

## Actions

Allow
- rolls package-owned demo evidence back ER-by-ER using the active DB policy;
- does not automatically rewrite unknown real application violations.

Warn
- dynamically examines active Beta ER policies;
- simulates WARN only where the active policy defines `human_review_required`;
- ERs without an active WARN lane are skipped;
- an active WARN lane without a safe deterministic repo simulator fails closed.

Block
- dynamically examines active Beta ER policies;
- simulates active `deny` lanes only;
- policy threshold crossings, regexes, dependency severity boundaries and effective values come from the DB; ER-075 required-test artifact profiles follow the product resolver (versioned ZeroUI governance configuration first, tenant structured thresholds second);
- unsupported active hard-block semantics fail closed.


## Automatic ALLOW lifecycle cleanup

`98-Restore-Original` is no longer required between normal demo scenarios once ALLOW has been verified.

- After an individual ALLOW scenario: run **Check Current Context** and verify ALLOW, then start the next scenario directly. The next scenario automatically restores the previous ALLOW lifecycle first.
- After WARN/DENY: run the matching rollback, run **Check Current Context** and verify recovery to ALLOW, then start the next scenario directly. The recovered ALLOW lifecycle is automatically restored first.
- WARN/DENY evidence is never auto-restored before rollback; those states remain fail-closed.
- `98-Restore-Original` remains available when you want immediate cleanup or you are ending the demo without starting another scenario.

This preserves the product-verification boundary: the pack does not claim the final governed decision and does not erase ALLOW evidence before you have an opportunity to run **Check Current Context**.

## Repository portability

The target repository is discovered with Git, not by a hardcoded path or repository name. The lifecycle supports repositories whose path contains spaces and uses `git rev-parse --git-path` for repository-internal state so Git worktrees are handled correctly.

Runtime configuration precedence is deterministic and non-interactive:
1. process environment (`ZEROUI_TENANT_DB_URL`, `ZEROUI_TENANT_ID` / `ZEROUI_DEMO_TENANT_ID`);
2. supported target-repository keys in `.vscode/settings.json`, `.cursor/settings.json`, or `.zeroui/runtime.json`;
3. packaged local-demo defaults: tenant DB `localhost:5433/zeroui_tenant_pg` and tenant `T/AMAZON/001`.

This means a clean target Git repository does not require manual tenant-ID or tenant-DB environment setup for the standard local demo. Environment/repository configuration still overrides the packaged defaults for other installations. The packaged DB connection default is routing/configuration only; ER threshold values are never packaged and are still loaded dynamically from the active tenant PostgreSQL runtime generation.

The PostgreSQL URL must resolve host, user and database (database in the URL path or `?dbname=`). `psql` is invoked with `-w`; bad/unreachable credentials fail closed instead of opening an interactive password prompt.

## Safety boundary

The pack does not modify/build/install/uninstall/reload the ZeroUI Extension or VSIX. The policy resolver performs no DB writes. The installed ZeroUI product remains authoritative for the final governed decision; run **Check Current Context** after simulation.

## v12.11 prepare reliability
Prepare now ensures the repository-root `.gitignore` exists and contains the exact current distribution-folder entry (for this combined pack: `/ZeroUI_Beta_ER_Demo_All_Scenarios_v12_11/`). Existing `.gitignore` content is preserved and duplicate entries are not added. The existing repo-local `.git/info/exclude` protection is also retained as a second safety net. The lifecycle treats only its exact controlled `.gitignore` delta as pack-owned so scenario clean-repo checks and rollbacks continue to work; explicit cleanup restores that delta only when the file has not been user-modified. Prepare verifies this exact current pack is ignored before reporting success.


## v12.11 ER-007 review fixture correction
The ER-007 Human Review simulator still reads `proof_lines` keys and requirements from the active tenant PostgreSQL policy, but it no longer writes the policy editor placeholder RHS (`...`) into the migration fixture. The product evaluator classifies placeholder proof values as invalid evidence. v12.11 writes deterministic non-placeholder demo evidence for the DB-governed proof keys so a risky migration with all governed controls can exercise the Human Review lane. No ER threshold/outcome is hardcoded.


## v12.11 ER-075 profile authority fix

ER-075 policy outcomes remain pinned to the active tenant PostgreSQL runtime generation. Required-test artifact profiles are not threshold values: Check Current Context resolves them from versioned ZeroUI governance configuration first, then tenant structured thresholds. The pack now mirrors that resolver using a versioned governance profile copied from the codebase source of truth, without scanning or modifying Extension/VSIX directories.


## v12.11 ER-072 HIGH DENY detector-witness fix

The ER-072 HIGH-CONFIDENCE-DENY fixture now synthesizes a varied witness from the active PostgreSQL detection rule instead of using degenerate repeated characters such as an AWS-style key ending in all zeroes. When the active policy publishes placeholder/masked/reference classification patterns, the fixture is checked against those patterns before it is written. HIGH DENY still does not require medium-only threshold fields, preserving v12.6/v12.7 behavior. No detector thresholds or secret values are hardcoded.

## v12.11 ER-072 production-shaped HIGH DENY fixture
ER-072 regex-rule fixtures now prefer a realistic assignment line whose key is derived from the active governed detector rule id/category and whose value is generated from that active rule's regex. For the governed AWS access-key detector this produces the shape `AWS_ACCESS_KEY_ID=<synthetic matching value>` rather than a bare token. The generator validates that the active regex still matches the assignment line and that the matched value is not classified as placeholder, masked, reference, or approved fixture. Anchored regexes retain the prior bare-witness fallback only when required by the active rule. No ER-072 detector threshold/value is hardcoded.

## v12.11 ER-072 save-event trigger fix

ER-072 production local detection is driven by the VS Code document-save path. After the pack writes an ER-072 ALLOW/WARN/DENY or recovery fixture, it now opens that exact generated file in the active VS Code window and sends the platform save shortcut (Ctrl+S on Windows, Cmd+S on macOS). The script then waits beyond the ER-072 save debounce before returning. This reproduces the existing product save path; it does not patch, build, install, reload, or otherwise modify the ZeroUI Extension/VSIX. If the IDE save shortcut cannot be delivered, ER-072 fails closed instead of claiming the scenario triggered.


## v12.11 Windows ER-072 VS Code open/save correction

On Windows, the ER-072 save-event helper now prefers the native `Code.exe` executable. If only the `code.cmd`/`code-insiders.cmd` launcher is available, it invokes that batch file through `cmd.exe /d /c call` with the executable path and arguments kept as separate process arguments. This removes the pre-quoted composite command that failed when the VS Code installation path contained spaces. The ER-072 flow still opens the generated evidence file, sends Ctrl+S, waits beyond the product debounce window, and fails closed if delivery cannot be completed. No Extension/VSIX source is modified.
