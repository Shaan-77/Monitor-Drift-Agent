$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') rollback --er 'ER-077' --scenario 'SAFE-DEPENDENCY-ALLOW' --expected-decision 'ALLOW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
