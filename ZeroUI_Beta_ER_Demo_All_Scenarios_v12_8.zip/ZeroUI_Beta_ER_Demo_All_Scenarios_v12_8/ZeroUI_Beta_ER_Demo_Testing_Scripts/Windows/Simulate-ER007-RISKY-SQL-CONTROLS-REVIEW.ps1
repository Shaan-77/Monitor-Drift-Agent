$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-007' --scenario 'RISKY-SQL-CONTROLS-REVIEW' --case-type 'HUMAN-REVIEW' --expected-decision 'HUMAN_REVIEW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
