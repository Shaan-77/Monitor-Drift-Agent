$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-007' --scenario 'RISKY-SQL-DENY' --case-type 'DENY' --expected-decision 'DENY'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
