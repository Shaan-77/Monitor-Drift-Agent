$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') rollback --er 'ER-074' --scenario 'COMPLIANT-BRANCH-ALLOW' --expected-decision 'ALLOW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
