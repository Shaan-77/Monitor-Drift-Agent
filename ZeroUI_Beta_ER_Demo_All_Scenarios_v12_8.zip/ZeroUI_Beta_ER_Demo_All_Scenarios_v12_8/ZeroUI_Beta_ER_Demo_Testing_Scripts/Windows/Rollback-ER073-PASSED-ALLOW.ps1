$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') rollback --er 'ER-073' --scenario 'PASSED-ALLOW' --expected-decision 'ALLOW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
