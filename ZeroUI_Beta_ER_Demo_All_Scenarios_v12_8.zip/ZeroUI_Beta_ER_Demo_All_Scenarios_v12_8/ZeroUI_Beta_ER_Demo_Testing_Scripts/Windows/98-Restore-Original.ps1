$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') restore
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
