$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-072' --scenario 'HIGH-CONFIDENCE-DENY' --case-type 'DENY' --expected-decision 'DENY'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
