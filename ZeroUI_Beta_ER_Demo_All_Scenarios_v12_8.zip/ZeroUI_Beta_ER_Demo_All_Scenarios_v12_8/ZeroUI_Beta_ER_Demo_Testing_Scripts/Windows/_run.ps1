$ErrorActionPreference = 'Stop'
$PackRoot = Split-Path -Parent $PSScriptRoot

function Resolve-Python3 {
    foreach ($name in @('python3','python')) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) {
            & $cmd.Source -c "import sys; raise SystemExit(0 if sys.version_info.major == 3 else 2)" 2>$null
            if ($LASTEXITCODE -eq 0) {
                return [pscustomobject]@{ Exe=$cmd.Source; Prefix=@() }
            }
        }
    }
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        & $py.Source -3 -c "import sys; raise SystemExit(0 if sys.version_info.major == 3 else 2)" 2>$null
        if ($LASTEXITCODE -eq 0) {
            return [pscustomobject]@{ Exe=$py.Source; Prefix=@('-3') }
        }
    }
    throw 'PYTHON3_REQUIRED: Python 3 is required.'
}

$Python = Resolve-Python3
& $Python.Exe @($Python.Prefix) (Join-Path $PackRoot 'Common\lifecycle.py') @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
