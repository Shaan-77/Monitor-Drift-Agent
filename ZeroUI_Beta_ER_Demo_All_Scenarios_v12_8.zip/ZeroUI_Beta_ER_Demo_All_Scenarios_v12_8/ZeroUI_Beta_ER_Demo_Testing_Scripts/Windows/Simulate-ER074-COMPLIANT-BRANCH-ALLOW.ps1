$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-074' --scenario 'COMPLIANT-BRANCH-ALLOW' --case-type 'ALLOW' --expected-decision 'ALLOW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
