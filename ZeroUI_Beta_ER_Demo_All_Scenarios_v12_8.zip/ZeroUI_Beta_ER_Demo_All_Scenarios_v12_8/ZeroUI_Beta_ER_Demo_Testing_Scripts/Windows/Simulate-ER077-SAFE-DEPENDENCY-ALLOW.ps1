$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-077' --scenario 'SAFE-DEPENDENCY-ALLOW' --case-type 'ALLOW' --expected-decision 'ALLOW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
