$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') cleanup
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
