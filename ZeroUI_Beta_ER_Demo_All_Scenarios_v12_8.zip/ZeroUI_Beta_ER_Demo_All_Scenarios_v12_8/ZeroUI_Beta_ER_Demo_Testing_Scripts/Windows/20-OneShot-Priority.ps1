﻿param([Parameter(Mandatory=$true)][ValidateSet('Setup','Allow','Block')][string]$Action)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$PackRoot=Split-Path -Parent $PSScriptRoot
$RepoRoot=(& git -C $PackRoot rev-parse --show-toplevel 2>$null).Trim()
if($LASTEXITCODE -ne 0 -or -not $RepoRoot){throw 'ONE_SHOT_FAILED=PACK_NOT_INSIDE_TARGET_GIT_REPOSITORY'}
function Resolve-Python3{$p=Get-Command python -ErrorAction SilentlyContinue;if($p){& $p.Source -c "import sys; raise SystemExit(0 if sys.version_info.major==3 else 2)" 2>$null;if($LASTEXITCODE -eq 0){return [pscustomobject]@{Exe=$p.Source;Prefix=@()}}};$p=Get-Command py -ErrorAction SilentlyContinue;if($p){& $p.Source -3 -c "import sys; raise SystemExit(0 if sys.version_info.major==3 else 2)" 2>$null;if($LASTEXITCODE -eq 0){return [pscustomobject]@{Exe=$p.Source;Prefix=@('-3')}}};throw 'ONE_SHOT_FAILED=PYTHON3_REQUIRED'}
$Python=Resolve-Python3
$env:ZEROUI_DEMO_REPO=$RepoRoot
Write-Output '============================================';Write-Output ' ZeroUI Beta Demo v8 Repo-Only';Write-Output '============================================';Write-Output "ACTION=$Action";Write-Output "TARGET_REPO=$RepoRoot";Write-Output 'EXTENSION_MUTATION=NO';Write-Output 'VSIX_MUTATION=NO';Write-Output 'EXTENSION_BUILD=NO';Write-Output 'EXTENSION_INSTALL=NO';Write-Output 'IDE_RELOAD=NO'
if($Action -eq 'Setup'){if(-not(Get-Command psql -ErrorAction SilentlyContinue)){throw 'ONE_SHOT_FAILED=PSQL_REQUIRED'};& (Join-Path $PackRoot 'Windows/00-Prepare-DemoRepo.ps1');exit $LASTEXITCODE}
if($Action -eq 'Allow'){& $Python.Exe @($Python.Prefix) (Join-Path $PackRoot 'Common/priority_engine.py') allow;if($LASTEXITCODE -ne 0){exit $LASTEXITCODE};Write-Output 'ONE_SHOT_RESULT=PASS';Write-Output 'ONE_SHOT_ACTION_RESULT=REPO_ALLOW_REMEDIATION_PASS';exit 0}
if(-not(Get-Command psql -ErrorAction SilentlyContinue)){throw 'ONE_SHOT_FAILED=PSQL_REQUIRED'}
$Readme=Join-Path $PackRoot 'README.md';& git -C $RepoRoot check-ignore -q -- $Readme;if($LASTEXITCODE -ne 0){& (Join-Path $PackRoot 'Windows/00-Prepare-DemoRepo.ps1');if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}}
& $Python.Exe @($Python.Prefix) (Join-Path $PackRoot 'Common/priority_engine.py') block
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE};Write-Output 'ONE_SHOT_RESULT=PASS';Write-Output 'ONE_SHOT_ACTION_RESULT=REPO_BLOCK_SIMULATION_PASS'
