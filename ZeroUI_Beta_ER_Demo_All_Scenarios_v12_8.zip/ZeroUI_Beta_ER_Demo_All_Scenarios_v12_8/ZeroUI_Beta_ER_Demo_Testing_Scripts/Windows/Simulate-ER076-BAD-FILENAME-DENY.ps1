$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-076' --scenario 'BAD-FILENAME-DENY' --case-type 'DENY' --expected-decision 'DENY'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
