$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') simulate --er 'ER-075' --scenario 'FAILING-TEST-DENY' --case-type 'DENY' --expected-decision 'DENY'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
