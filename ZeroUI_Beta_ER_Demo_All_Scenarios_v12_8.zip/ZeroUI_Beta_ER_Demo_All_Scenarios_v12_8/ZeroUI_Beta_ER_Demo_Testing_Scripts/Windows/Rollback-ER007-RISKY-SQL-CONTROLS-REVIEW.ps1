$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') rollback --er 'ER-007' --scenario 'RISKY-SQL-CONTROLS-REVIEW' --expected-decision 'HUMAN_REVIEW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
