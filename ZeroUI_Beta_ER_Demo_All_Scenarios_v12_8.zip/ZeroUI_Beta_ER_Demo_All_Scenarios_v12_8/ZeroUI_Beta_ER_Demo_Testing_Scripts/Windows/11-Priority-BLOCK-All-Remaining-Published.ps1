﻿$ErrorActionPreference='Stop'
$PackRoot=Split-Path -Parent $PSScriptRoot
python (Join-Path $PackRoot 'Common/priority_engine.py') block
exit $LASTEXITCODE
