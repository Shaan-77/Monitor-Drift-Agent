$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') rollback --er 'ER-001' --scenario 'LINE-COUNT-REVIEW' --expected-decision 'HUMAN_REVIEW'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
