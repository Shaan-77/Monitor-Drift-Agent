$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') prepare
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
