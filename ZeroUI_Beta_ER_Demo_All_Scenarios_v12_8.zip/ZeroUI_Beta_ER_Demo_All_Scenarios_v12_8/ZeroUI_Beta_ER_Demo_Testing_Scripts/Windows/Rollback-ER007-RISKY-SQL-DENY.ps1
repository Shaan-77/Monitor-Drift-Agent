$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '_run.ps1') rollback --er 'ER-007' --scenario 'RISKY-SQL-DENY' --expected-decision 'DENY'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
