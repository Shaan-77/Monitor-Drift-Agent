#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-074 --scenario COMPLIANT-BRANCH-ALLOW --case-type ALLOW --expected-decision ALLOW
