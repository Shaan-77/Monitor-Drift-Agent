#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
PACK_ROOT="${SCRIPT_DIR:h}"
exec python3 "$PACK_ROOT/Common/priority_engine.py" allow
