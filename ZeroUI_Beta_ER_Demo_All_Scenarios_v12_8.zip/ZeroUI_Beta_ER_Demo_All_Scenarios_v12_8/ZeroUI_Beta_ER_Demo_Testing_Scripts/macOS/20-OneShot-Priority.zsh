#!/bin/zsh
set -euo pipefail
PACK_ROOT="${0:A:h:h}"
REPO_ROOT="$(git -C "$PACK_ROOT" rev-parse --show-toplevel 2>/dev/null || true)"
[[ -n "$REPO_ROOT" ]] || { print -u2 -- "ONE_SHOT_FAILED=PACK_NOT_INSIDE_TARGET_GIT_REPOSITORY"; exit 2; }
ACTION="${1:-}"
case "$ACTION" in setup|allow|block) ;; *) print -u2 -- "USAGE: zsh \"$0\" setup|allow|block"; exit 2 ;; esac
command -v git >/dev/null 2>&1 || { print -u2 -- "ONE_SHOT_FAILED=GIT_REQUIRED"; exit 2; }
command -v python3 >/dev/null 2>&1 || { print -u2 -- "ONE_SHOT_FAILED=PYTHON3_REQUIRED"; exit 2; }
export ZEROUI_DEMO_REPO="$REPO_ROOT"
print -- "============================================"
print -- " ZeroUI Beta Demo v8 Repo-Only"
print -- "============================================"
print -- "ACTION=$ACTION"
print -- "TARGET_REPO=$REPO_ROOT"
print -- "EXTENSION_MUTATION=NO"
print -- "VSIX_MUTATION=NO"
print -- "EXTENSION_BUILD=NO"
print -- "EXTENSION_INSTALL=NO"
print -- "IDE_RELOAD=NO"
if [[ "$ACTION" == "setup" ]]; then
 command -v psql >/dev/null 2>&1 || { print -u2 -- "ONE_SHOT_FAILED=PSQL_REQUIRED"; exit 2; }
 zsh "$PACK_ROOT/macOS/00-Prepare-DemoRepo.zsh"
 print -- "ONE_SHOT_RESULT=PASS"; print -- "SETUP_COMPLETE=YES"; exit 0
fi
if [[ "$ACTION" == "allow" ]]; then
 python3 "$PACK_ROOT/Common/priority_engine.py" allow
 print -- "ONE_SHOT_RESULT=PASS"; print -- "ONE_SHOT_ACTION_RESULT=REPO_ALLOW_REMEDIATION_PASS"; exit 0
fi
command -v psql >/dev/null 2>&1 || { print -u2 -- "ONE_SHOT_FAILED=PSQL_REQUIRED"; exit 2; }
if ! git -C "$REPO_ROOT" check-ignore -q -- "$PACK_ROOT/README.md"; then zsh "$PACK_ROOT/macOS/00-Prepare-DemoRepo.zsh"; fi
python3 "$PACK_ROOT/Common/priority_engine.py" block
print -- "ONE_SHOT_RESULT=PASS"; print -- "ONE_SHOT_ACTION_RESULT=REPO_BLOCK_SIMULATION_PASS"
