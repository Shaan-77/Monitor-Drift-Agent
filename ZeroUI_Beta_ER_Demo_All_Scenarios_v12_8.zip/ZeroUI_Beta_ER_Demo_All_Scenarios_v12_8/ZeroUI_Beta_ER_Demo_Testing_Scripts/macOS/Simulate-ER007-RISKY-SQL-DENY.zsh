#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-007 --scenario RISKY-SQL-DENY --case-type DENY --expected-decision DENY
