#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-077 --scenario SAFE-DEPENDENCY-ALLOW --case-type ALLOW --expected-decision ALLOW
