#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" rollback --er ER-075 --scenario PASSING-TEST-ALLOW --expected-decision ALLOW
