#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" rollback --er ER-007 --scenario RISKY-SQL-DENY --expected-decision DENY
