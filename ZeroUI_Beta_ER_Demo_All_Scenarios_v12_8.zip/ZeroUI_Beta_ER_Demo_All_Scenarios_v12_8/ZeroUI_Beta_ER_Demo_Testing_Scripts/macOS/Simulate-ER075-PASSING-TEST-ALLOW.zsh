#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-075 --scenario PASSING-TEST-ALLOW --case-type ALLOW --expected-decision ALLOW
