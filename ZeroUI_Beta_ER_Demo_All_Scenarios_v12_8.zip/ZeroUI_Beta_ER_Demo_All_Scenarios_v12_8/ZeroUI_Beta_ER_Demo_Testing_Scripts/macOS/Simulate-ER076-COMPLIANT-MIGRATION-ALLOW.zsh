#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-076 --scenario COMPLIANT-MIGRATION-ALLOW --case-type ALLOW --expected-decision ALLOW
