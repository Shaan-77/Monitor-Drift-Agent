#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-007 --scenario RISKY-SQL-CONTROLS-REVIEW --case-type HUMAN-REVIEW --expected-decision HUMAN_REVIEW
