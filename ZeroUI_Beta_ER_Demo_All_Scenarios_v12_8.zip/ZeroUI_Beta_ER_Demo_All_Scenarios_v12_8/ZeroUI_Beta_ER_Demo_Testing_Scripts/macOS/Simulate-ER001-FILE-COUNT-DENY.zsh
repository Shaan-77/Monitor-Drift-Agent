#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-001 --scenario FILE-COUNT-DENY --case-type DENY --expected-decision DENY
