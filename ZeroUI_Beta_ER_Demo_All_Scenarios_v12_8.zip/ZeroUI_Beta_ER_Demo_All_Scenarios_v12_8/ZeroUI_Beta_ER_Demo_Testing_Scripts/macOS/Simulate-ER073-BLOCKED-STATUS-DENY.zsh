#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-073 --scenario BLOCKED-STATUS-DENY --case-type DENY --expected-decision DENY
