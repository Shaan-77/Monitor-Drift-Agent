#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" simulate --er ER-074 --scenario NONCOMPLIANT-BRANCH-DENY --case-type DENY --expected-decision DENY
