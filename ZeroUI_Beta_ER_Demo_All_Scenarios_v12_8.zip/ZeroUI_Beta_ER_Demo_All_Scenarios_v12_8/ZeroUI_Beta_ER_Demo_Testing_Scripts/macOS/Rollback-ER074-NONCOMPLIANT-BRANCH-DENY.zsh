#!/bin/zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
exec zsh "$SCRIPT_DIR/_run.zsh" rollback --er ER-074 --scenario NONCOMPLIANT-BRANCH-DENY --expected-decision DENY
