#!/usr/bin/env python3
"""
Read-only resolver for the FM-09 active tenant PostgreSQL runtime policy.

Authority path:
  app.governed_er_runtime_generations (generation_state='active')
    -> app.governed_er_runtime_generation_members (exact ER pin)
    -> exact tenant_threshold_version_id
    -> relational parameter/value + governed-rule tables

No "latest version" selection and no threshold fallback are permitted.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from urllib.parse import parse_qsl, unquote, urlsplit, urlunsplit
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from runtime_config import RuntimeConfigError, resolve_runtime


class DemoPolicyError(RuntimeError):
    pass


def _sql_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _normalize_db_url(raw: str) -> str:
    url = raw.strip()
    for prefix in ("postgresql+psycopg://", "postgresql+psycopg2://", "postgres+psycopg://"):
        if url.startswith(prefix):
            return "postgresql://" + url.split("://", 1)[1]
    if url.startswith("postgres://"):
        return "postgresql://" + url[len("postgres://"):]
    return url


_RUNTIME: dict[str, Any] | None = None


def _repo_root_for_runtime_resolution() -> Path:
    raw = (os.environ.get("ZEROUI_DEMO_REPO") or "").strip()
    if raw:
        return Path(raw).resolve()
    return Path.cwd().resolve()


def _runtime_config() -> dict[str, Any]:
    global _RUNTIME
    if _RUNTIME is not None:
        return _RUNTIME
    try:
        _RUNTIME = resolve_runtime(_repo_root_for_runtime_resolution())
    except RuntimeConfigError as exc:
        raise DemoPolicyError(str(exc)) from exc
    return _RUNTIME


def _candidate_db_urls() -> list[str]:
    runtime = _runtime_config()
    raw = str(runtime.get("tenant_db_url") or "").strip()
    if not raw:
        raise DemoPolicyError("TENANT_DB_CONFIG_UNRESOLVED")
    primary = _normalize_db_url(raw)
    candidates = [primary]

    # Local-DEV compatibility: when a repository carries the Docker-internal
    # tenant DB endpoint, also try the host-published endpoint.  This is only a
    # connection-location fallback; it does not change tenant or policy data.
    try:
        parsed = urlsplit(primary)
        if parsed.hostname == "dev-pg-tenant" and (parsed.port or 5432) == 5432:
            userinfo = ""
            if parsed.username is not None:
                userinfo = parsed.username
                if parsed.password is not None:
                    userinfo += ":" + parsed.password
                userinfo += "@"
            translated = urlunsplit((
                parsed.scheme,
                f"{userinfo}127.0.0.1:5433",
                parsed.path,
                parsed.query,
                parsed.fragment,
            ))
            if translated != primary:
                candidates.append(translated)
    except ValueError:
        # The detailed validation below will report the malformed URL without
        # silently falling back to another policy source.
        pass
    return candidates


# URI query parameter -> libpq environment variable.  These preserve common
# PostgreSQL connection semantics without putting credentials in argv.
_LIBPQ_QUERY_ENV = {
    "host": "PGHOST",
    "hostaddr": "PGHOSTADDR",
    "port": "PGPORT",
    "dbname": "PGDATABASE",
    "user": "PGUSER",
    "password": "PGPASSWORD",
    "passfile": "PGPASSFILE",
    "channel_binding": "PGCHANNELBINDING",
    "connect_timeout": "PGCONNECT_TIMEOUT",
    "client_encoding": "PGCLIENTENCODING",
    "options": "PGOPTIONS",
    "application_name": "PGAPPNAME",
    "keepalives": "PGKEEPALIVES",
    "keepalives_idle": "PGKEEPALIVESIDLE",
    "keepalives_interval": "PGKEEPALIVESINTERVAL",
    "keepalives_count": "PGKEEPALIVESCOUNT",
    "tcp_user_timeout": "PGTCPUSER_TIMEOUT",
    "sslmode": "PGSSLMODE",
    "sslcert": "PGSSLCERT",
    "sslkey": "PGSSLKEY",
    "sslpassword": "PGSSLPASSWORD",
    "sslrootcert": "PGSSLROOTCERT",
    "sslcrl": "PGSSLCRL",
    "sslcrldir": "PGSSLCRLDIR",
    "sslsni": "PGSSLSNI",
    "requirepeer": "PGREQUIREPEER",
    "ssl_min_protocol_version": "PGSSLMINPROTOCOLVERSION",
    "ssl_max_protocol_version": "PGSSLMAXPROTOCOLVERSION",
    "gssencmode": "PGGSSENCMODE",
    "krbsrvname": "PGKRBSRVNAME",
    "gsslib": "PGGSSLIB",
    "target_session_attrs": "PGTARGETSESSIONATTRS",
    "load_balance_hosts": "PGLOADBALANCEHOSTS",
}


def _psql_env_for_url(url: str) -> dict[str, str]:
    """Build a non-interactive libpq environment from a PostgreSQL URI.

    We intentionally do not place the URI on the psql command line because it
    may contain credentials.  We also do not assign the full URI to PGDATABASE:
    some psql/libpq combinations interpret that value as a literal database
    name rather than a connection URI.
    """
    normalized = _normalize_db_url(url)
    try:
        parsed = urlsplit(normalized)
        # Accessing .port performs validation and can raise ValueError.
        port = parsed.port
    except ValueError as exc:
        raise DemoPolicyError("TENANT_DB_URL_INVALID: malformed host/port") from exc

    if parsed.scheme not in {"postgresql", "postgres"}:
        raise DemoPolicyError(
            "TENANT_DB_URL_INVALID: expected postgresql:// or postgres:// connection URL."
        )

    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    host = unquote(parsed.hostname or query.get("host", "")).strip()
    username = unquote(parsed.username or query.get("user", "")).strip()
    password = unquote(parsed.password) if parsed.password is not None else query.get("password", "")
    database = unquote((parsed.path or "").lstrip("/")) or query.get("dbname", "").strip()

    if not host:
        raise DemoPolicyError("TENANT_DB_URL_INVALID: host is required.")
    if not username:
        raise DemoPolicyError("TENANT_DB_URL_INVALID: user is required.")
    if not database:
        raise DemoPolicyError(
            "TENANT_DB_URL_INVALID: database name is required in the URL path or ?dbname=."
        )

    env = os.environ.copy()

    # Clear values that could redirect the connection away from the governed
    # URL.  Other benign libpq settings remain available unless overridden by
    # URL query parameters below.
    for key in ("PGSERVICE", "PGSERVICEFILE", "PGHOST", "PGHOSTADDR", "PGPORT", "PGUSER", "PGPASSWORD", "PGDATABASE"):
        env.pop(key, None)

    env["PGHOST"] = host
    if port is not None:
        env["PGPORT"] = str(port)
    env["PGUSER"] = username
    if password:
        env["PGPASSWORD"] = password
    env["PGDATABASE"] = database

    for key, value in query.items():
        target = _LIBPQ_QUERY_ENV.get(key)
        if target and value != "":
            env[target] = value

    return env


def _psql_executable() -> str:
    found = shutil.which("psql")
    if not found:
        raise DemoPolicyError("PSQL_REQUIRED: psql is required for read-only tenant PostgreSQL policy resolution.")
    return found


def _run_psql(sql: str, *, tenant_context: str | None = None) -> list[str]:
    psql = _psql_executable()
    errors: list[str] = []
    statement = sql
    if tenant_context:
        statement = (
            "BEGIN; SET LOCAL zeroui.tenant_id = "
            + _sql_literal(tenant_context)
            + "; " + sql + "; COMMIT;"
        )
    for url in _candidate_db_urls():
        try:
            env = _psql_env_for_url(url)
        except DemoPolicyError as exc:
            errors.append(str(exc))
            continue
        proc = subprocess.run(
            [psql, "-X", "-w", "-q", "-v", "ON_ERROR_STOP=1", "-At", "-F", "\t", "-c", statement],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )
        if proc.returncode == 0:
            return [line for line in proc.stdout.splitlines()]
        errors.append(proc.stderr.strip() or f"exit={proc.returncode}")
    raise DemoPolicyError("DB_READ_FAILED: " + " | ".join(errors))


def _typed(row: dict[str, str]) -> Any:
    kind = row.get("value_type", "")
    if kind == "boolean":
        raw = row.get("boolean_value", "").strip().lower()
        return raw in {"t", "true", "1", "yes"}
    if kind == "integer":
        raw = row.get("integer_value", "")
        return int(raw) if raw != "" else None
    if kind == "decimal":
        raw = row.get("decimal_value", "")
        if raw == "":
            return None
        number = float(raw)
        return int(number) if number.is_integer() else number
    return row.get("string_value", "")


def _tsv_rows(sql: str, columns: list[str], *, tenant_context: str | None = None) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for line in _run_psql(sql, tenant_context=tenant_context):
        parts = line.split("\t")
        parts += [""] * (len(columns) - len(parts))
        result.append(dict(zip(columns, parts[:len(columns)])))
    return result


def resolve_tenant_id() -> str:
    runtime = _runtime_config()
    explicit = str(runtime.get("tenant_id") or "").strip()
    if explicit:
        return explicit
    rows = [r.strip() for r in _run_psql(
        "SELECT DISTINCT tenant_id FROM app.governed_er_runtime_generations "
        "WHERE generation_state='active' ORDER BY tenant_id"
    ) if r.strip()]
    if len(rows) == 1:
        return rows[0]
    if not rows:
        raise DemoPolicyError("TENANT_ID_UNRESOLVED: no tenant has an active runtime generation.")
    raise DemoPolicyError(
        "TENANT_ID_AMBIGUOUS: target-repo/process configuration does not identify a tenant "
        "and multiple tenants have active runtime generations."
    )


def _load_meta(tenant_id: str, er_id: str) -> dict[str, Any]:
    sql = f"""
SELECT g.runtime_generation_id::text,
       g.generation_sequence::text,
       g.generation_sha256,
       m.tenant_threshold_version_id::text,
       m.threshold_version::text,
       m.policy_sha256,
       v.version_state,
       COALESCE(v.no_match_outcome,'')
FROM app.governed_er_runtime_generations g
JOIN app.governed_er_runtime_generation_members m
  ON m.runtime_generation_id=g.runtime_generation_id
 AND m.tenant_id=g.tenant_id
JOIN app.governed_er_threshold_versions v
  ON v.tenant_threshold_version_id=m.tenant_threshold_version_id
 AND v.tenant_id=m.tenant_id
WHERE g.tenant_id={_sql_literal(tenant_id)}
  AND g.generation_state='active'
  AND m.er_id={_sql_literal(er_id)}
ORDER BY g.generation_sequence;
"""
    rows = _tsv_rows(sql, [
        "runtime_generation_id", "generation_sequence", "generation_sha256",
        "tenant_threshold_version_id", "threshold_version", "policy_sha256",
        "version_state", "no_match_outcome",
    ], tenant_context=tenant_id)
    if len(rows) == 0:
        raise DemoPolicyError(f"DB_ACTIVE_POLICY_MISSING: tenant={tenant_id} er={er_id}")
    if len(rows) != 1:
        raise DemoPolicyError(f"DB_ACTIVE_POLICY_AMBIGUOUS: tenant={tenant_id} er={er_id} rows={len(rows)}")
    row = rows[0]
    if row["version_state"].lower() != "published":
        raise DemoPolicyError(
            f"DB_ACTIVE_POLICY_NOT_PUBLISHED: er={er_id} state={row['version_state']}"
        )
    return {
        "tenantId": tenant_id,
        "erId": er_id,
        "runtimeGenerationId": row["runtime_generation_id"],
        "generationSequence": int(row["generation_sequence"]),
        "generationHash": row["generation_sha256"],
        "tenantThresholdVersionId": row["tenant_threshold_version_id"],
        "thresholdVersion": int(row["threshold_version"]),
        "canonicalPolicyHash": row["policy_sha256"],
        "versionState": row["version_state"],
        "noMatchOutcome": row["no_match_outcome"] or None,
        "sourceAuthority": "tenant_postgresql",
    }


def _load_parameters(version_id: str, tenant_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    vid = _sql_literal(version_id)
    defs = _tsv_rows(f"""
SELECT version_parameter_id::text, parameter_id, data_type, required::text,
       COALESCE(unit,''), COALESCE(integer_min::text,''), COALESCE(integer_max::text,''),
       COALESCE(decimal_min::text,''), COALESCE(decimal_max::text,'')
FROM app.governed_er_threshold_version_parameters
WHERE tenant_threshold_version_id={vid}::uuid
ORDER BY sort_order, parameter_id;
""", ["version_parameter_id","parameter_id","data_type","required","unit",
      "integer_min","integer_max","decimal_min","decimal_max"], tenant_context=tenant_id)

    schemas: list[dict[str, Any]] = []
    by_vpid: dict[str, dict[str, str]] = {}
    for d in defs:
        by_vpid[d["version_parameter_id"]] = d
        s: dict[str, Any] = {
            "parameter_id": d["parameter_id"],
            "type": d["data_type"],
            "required": d["required"].lower() in {"t","true","1"},
        }
        if d["unit"]:
            s["unit"] = d["unit"]
        for k in ("integer_min","integer_max"):
            if d[k] != "":
                s[k] = int(d[k])
        for k in ("decimal_min","decimal_max"):
            if d[k] != "":
                s[k] = float(d[k])
        schemas.append(s)

    effective: dict[str, Any] = {}

    scalar_rows = _tsv_rows(f"""
SELECT p.parameter_id, v.value_role, v.value_type,
       COALESCE(v.string_value,''), COALESCE(v.integer_value::text,''),
       COALESCE(v.decimal_value::text,''), COALESCE(v.boolean_value::text,'')
FROM app.governed_er_threshold_parameter_scalar_values v
JOIN app.governed_er_threshold_version_parameters p
  ON p.version_parameter_id=v.version_parameter_id
WHERE p.tenant_threshold_version_id={vid}::uuid
ORDER BY p.sort_order, p.parameter_id, v.value_role;
""", ["parameter_id","value_role","value_type","string_value","integer_value","decimal_value","boolean_value"], tenant_context=tenant_id)
    for row in scalar_rows:
        if row["value_role"] == "effective":
            effective[row["parameter_id"]] = _typed(row)

    list_rows = _tsv_rows(f"""
SELECT p.parameter_id, li.item_index::text, li.value_type,
       COALESCE(li.string_value,''), COALESCE(li.integer_value::text,''),
       COALESCE(li.decimal_value::text,''), COALESCE(li.boolean_value::text,'')
FROM app.governed_er_threshold_parameter_list_items li
JOIN app.governed_er_threshold_version_parameters p
  ON p.version_parameter_id=li.version_parameter_id
WHERE p.tenant_threshold_version_id={vid}::uuid
ORDER BY p.sort_order, p.parameter_id, li.item_index;
""", ["parameter_id","item_index","value_type","string_value","integer_value","decimal_value","boolean_value"], tenant_context=tenant_id)
    lists: dict[str, list[Any]] = {}
    for row in list_rows:
        lists.setdefault(row["parameter_id"], []).append(_typed(row))
    effective.update(lists)

    node_rows = _tsv_rows(f"""
SELECT n.config_node_id::text, n.version_parameter_id::text,
       COALESCE(n.parent_node_id::text,''), COALESCE(n.node_name,''),
       n.node_kind, COALESCE(n.item_index::text,''),
       COALESCE(sv.value_type,''), COALESCE(sv.string_value,''),
       COALESCE(sv.integer_value::text,''), COALESCE(sv.decimal_value::text,''),
       COALESCE(sv.boolean_value::text,'')
FROM app.governed_er_threshold_config_nodes n
LEFT JOIN app.governed_er_threshold_config_scalar_values sv
  ON sv.config_node_id=n.config_node_id
WHERE n.tenant_threshold_version_id={vid}::uuid
ORDER BY n.version_parameter_id, n.parent_node_id NULLS FIRST,
         n.item_index NULLS FIRST, n.node_name, n.config_node_id;
""", ["id","vpid","parent","name","kind","item_index","value_type",
      "string_value","integer_value","decimal_value","boolean_value"], tenant_context=tenant_id)
    nodes = {n["id"]: n for n in node_rows}
    children: dict[str, list[str]] = {}
    roots: dict[str, str] = {}
    for n in node_rows:
        if n["parent"]:
            children.setdefault(n["parent"], []).append(n["id"])
        else:
            roots[n["vpid"]] = n["id"]

    def node_value(node_id: str) -> Any:
        n = nodes[node_id]
        if n["kind"] == "scalar":
            return _typed(n)
        kids = children.get(node_id, [])
        if n["kind"] == "object":
            result: dict[str, Any] = {}
            for cid in sorted(kids, key=lambda x: (nodes[x]["name"], nodes[x]["item_index"], x)):
                child = nodes[cid]
                result[child["name"]] = node_value(cid)
            return result
        ordered = sorted(
            kids,
            key=lambda x: (
                int(nodes[x]["item_index"]) if nodes[x]["item_index"] != "" else 10**9,
                nodes[x]["name"],
                x,
            ),
        )
        return [node_value(cid) for cid in ordered]

    for vpid, root in roots.items():
        definition = by_vpid.get(vpid)
        if definition:
            effective[definition["parameter_id"]] = node_value(root)

    return schemas, effective


def _load_rules(version_id: str, effective_values: dict[str, Any], tenant_id: str) -> list[dict[str, Any]]:
    vid = _sql_literal(version_id)
    rules = _tsv_rows(f"""
SELECT version_rule_id::text, rule_id, priority::text, outcome,
       COALESCE(root_condition_group_id::text,''), COALESCE(root_condition_id::text,'')
FROM app.governed_er_threshold_version_rules
WHERE tenant_threshold_version_id={vid}::uuid
ORDER BY sort_order, rule_id;
""", ["version_rule_id","rule_id","priority","outcome","root_group","root_condition"], tenant_context=tenant_id)

    groups = _tsv_rows(f"""
SELECT condition_group_id::text, COALESCE(parent_group_id::text,''),
       COALESCE(parent_condition_id::text,''), kind, sort_order::text
FROM app.governed_er_threshold_rule_condition_groups
WHERE tenant_threshold_version_id={vid}::uuid
ORDER BY sort_order, condition_group_id;
""", ["id","parent_group","parent_condition","kind","sort_order"], tenant_context=tenant_id)
    group_by_id = {g["id"]: g for g in groups}

    conds = _tsv_rows(f"""
SELECT c.condition_id::text, c.condition_group_id::text, c.sort_order::text,
       c.operator, c.lhs_fact_id, c.rhs_kind, COALESCE(c.unit,''),
       COALESCE(pr.parameter_id,''),
       COALESCE(lv.value_type,''), COALESCE(lv.string_value,''),
       COALESCE(lv.integer_value::text,''), COALESCE(lv.decimal_value::text,''),
       COALESCE(lv.boolean_value::text,'')
FROM app.governed_er_threshold_rule_conditions c
LEFT JOIN app.governed_er_threshold_condition_parameter_refs pr
  ON pr.condition_id=c.condition_id
LEFT JOIN app.governed_er_threshold_condition_literal_values lv
  ON lv.condition_id=c.condition_id
JOIN app.governed_er_threshold_rule_condition_groups g
  ON g.condition_group_id=c.condition_group_id
WHERE g.tenant_threshold_version_id={vid}::uuid
ORDER BY c.sort_order, c.condition_id;
""", ["id","group_id","sort_order","operator","lhs_fact_id","rhs_kind","unit",
      "parameter_id","value_type","string_value","integer_value","decimal_value","boolean_value"], tenant_context=tenant_id)
    cond_by_id = {c["id"]: c for c in conds}
    conds_by_group: dict[str, list[str]] = {}
    for c in conds:
        conds_by_group.setdefault(c["group_id"], []).append(c["id"])

    literal_lists = _tsv_rows(f"""
SELECT li.condition_id::text, li.sort_order::text, li.value_type,
       COALESCE(li.string_value,''), COALESCE(li.integer_value::text,''),
       COALESCE(li.decimal_value::text,''), COALESCE(li.boolean_value::text,'')
FROM app.governed_er_threshold_condition_literal_list_items li
JOIN app.governed_er_threshold_rule_conditions c ON c.condition_id=li.condition_id
JOIN app.governed_er_threshold_rule_condition_groups g ON g.condition_group_id=c.condition_group_id
WHERE g.tenant_threshold_version_id={vid}::uuid
ORDER BY li.condition_id, li.sort_order;
""", ["condition_id","sort_order","value_type","string_value","integer_value","decimal_value","boolean_value"], tenant_context=tenant_id)
    list_by_cond: dict[str, list[Any]] = {}
    for item in literal_lists:
        list_by_cond.setdefault(item["condition_id"], []).append(_typed(item))

    child_groups: dict[str, list[str]] = {}
    for g in groups:
        if g["parent_group"]:
            child_groups.setdefault(g["parent_group"], []).append(g["id"])

    def condition_ast(cid: str) -> dict[str, Any]:
        c = cond_by_id[cid]
        ast: dict[str, Any] = {
            "kind": "predicate",
            "factId": c["lhs_fact_id"],
            "operator": c["operator"],
        }
        if c["unit"]:
            ast["unit"] = c["unit"]
        if c["rhs_kind"] == "parameter_ref":
            pid = c["parameter_id"]
            ast["value"] = {"kind": "threshold_ref", "parameter_id": pid}
            ast["resolvedValue"] = effective_values.get(pid)
        elif c["rhs_kind"] == "literal_scalar":
            ast["value"] = _typed(c)
        elif c["rhs_kind"] == "literal_list":
            ast["value"] = list_by_cond.get(cid, [])
        return ast

    def group_ast(gid: str) -> dict[str, Any]:
        g = group_by_id[gid]
        nodes: list[dict[str, Any]] = []
        for child_gid in sorted(child_groups.get(gid, []), key=lambda x: int(group_by_id[x]["sort_order"])):
            nodes.append(group_ast(child_gid))
        for cid in sorted(conds_by_group.get(gid, []), key=lambda x: int(cond_by_id[x]["sort_order"])):
            nodes.append(condition_ast(cid))
        kind = g["kind"]
        if kind == "not":
            return {"kind": "not", "node": nodes[0] if nodes else {}}
        if len(nodes) == 1 and kind in {"all","any"}:
            return nodes[0]
        return {"kind": kind, "nodes": nodes}

    result: list[dict[str, Any]] = []
    for r in rules:
        if r["root_condition"]:
            ast = condition_ast(r["root_condition"])
        elif r["root_group"]:
            ast = group_ast(r["root_group"])
        else:
            ast = {}
        result.append({
            "rule_id": r["rule_id"],
            "priority": int(r["priority"]),
            "outcome": r["outcome"],
            "ast": ast,
        })
    return result


def _verify_assignment(tenant_id: str, er_id: str) -> None:
    exists = _run_psql("SELECT CASE WHEN to_regclass('app.governed_er_tenant_product_assignment') "
                       "IS NULL THEN '0' ELSE '1' END", tenant_context=tenant_id)
    if not exists or exists[0].strip() != "1":
        return
    rows = _run_psql(
        "SELECT COUNT(*)::text FROM app.governed_er_tenant_product_assignment "
        f"WHERE tenant_id={_sql_literal(tenant_id)} AND er_id={_sql_literal(er_id)} "
        "AND assignment_status='active'",
        tenant_context=tenant_id,
    )
    if not rows or int(rows[0].strip() or "0") != 1:
        raise DemoPolicyError(
            f"DB_ACTIVE_PRODUCT_ASSIGNMENT_MISSING: tenant={tenant_id} er={er_id}"
        )


def list_active_published_er_ids(*, tenant_id: str | None = None) -> list[str]:
    """Return ER IDs pinned in the tenant's single active runtime generation and published.

    This is read-only authority discovery; it never selects a latest threshold version.
    """
    tenant = tenant_id or resolve_tenant_id()
    rows = _run_psql(
        "SELECT m.er_id "
        "FROM app.governed_er_runtime_generations g "
        "JOIN app.governed_er_runtime_generation_members m "
        "  ON m.runtime_generation_id=g.runtime_generation_id AND m.tenant_id=g.tenant_id "
        "JOIN app.governed_er_threshold_versions v "
        "  ON v.tenant_threshold_version_id=m.tenant_threshold_version_id AND v.tenant_id=m.tenant_id "
        f"WHERE g.tenant_id={_sql_literal(tenant)} "
        "AND g.generation_state='active' AND v.version_state='published' "
        "ORDER BY m.er_id",
        tenant_context=tenant,
    )
    ids = [row.strip() for row in rows if row.strip()]
    if len(ids) != len(set(ids)):
        raise DemoPolicyError(f"DB_ACTIVE_PUBLISHED_ER_DUPLICATE: tenant={tenant}")
    return ids


def load_active_policy(er_id: str, *, tenant_id: str | None = None) -> dict[str, Any]:
    tenant = tenant_id or resolve_tenant_id()
    meta = _load_meta(tenant, er_id)
    _verify_assignment(tenant, er_id)
    schemas, effective = _load_parameters(meta["tenantThresholdVersionId"], tenant)
    rules = _load_rules(meta["tenantThresholdVersionId"], effective, tenant)
    return {
        **meta,
        "parameterSchemas": schemas,
        "effectiveParameterValues": effective,
        "governedRules": rules,
    }



def resolve_active_runtime_generation_id(*, tenant_id: str | None = None) -> str:
    """Return the tenant's one active runtime generation id; fail closed otherwise."""
    tenant = tenant_id or resolve_tenant_id()
    rows = [
        row.strip()
        for row in _run_psql(
            "SELECT runtime_generation_id::text "
            "FROM app.governed_er_runtime_generations "
            f"WHERE tenant_id={_sql_literal(tenant)} "
            "AND generation_state='active' "
            "ORDER BY generation_sequence",
            tenant_context=tenant,
        )
        if row.strip()
    ]
    if len(rows) == 0:
        raise DemoPolicyError(
            f"DB_ACTIVE_RUNTIME_GENERATION_MISSING: tenant={tenant}"
        )
    if len(rows) != 1:
        raise DemoPolicyError(
            f"DB_ACTIVE_RUNTIME_GENERATION_AMBIGUOUS: tenant={tenant} rows={len(rows)}"
        )
    return rows[0]


def load_active_policy_set(er_ids: list[str] | tuple[str, ...]) -> dict[str, dict[str, Any]]:
    """Resolve an ER policy set strictly from one active runtime generation.

    There is no latest-published selection, repository threshold fallback,
    environment threshold default, or built-in threshold value.
    """
    tenant = resolve_tenant_id()
    generation_before = resolve_active_runtime_generation_id(tenant_id=tenant)

    policies: dict[str, dict[str, Any]] = {}
    for er_id in er_ids:
        policy = load_active_policy(er_id, tenant_id=tenant)
        if str(policy.get("runtimeGenerationId") or "") != generation_before:
            raise DemoPolicyError(
                "DB_ACTIVE_RUNTIME_GENERATION_CHANGED_DURING_POLICY_RESOLUTION: "
                f"er={er_id} expected={generation_before} "
                f"actual={policy.get('runtimeGenerationId')}"
            )
        policies[er_id] = policy

    generation_after = resolve_active_runtime_generation_id(tenant_id=tenant)
    if generation_after != generation_before:
        raise DemoPolicyError(
            "DB_ACTIVE_RUNTIME_GENERATION_CHANGED_DURING_POLICY_RESOLUTION: "
            f"before={generation_before} after={generation_after}"
        )

    if set(policies) != set(er_ids):
        raise DemoPolicyError("DB_ACTIVE_POLICY_SET_INCOMPLETE")

    return policies


def effective_policy_payload(policy: dict[str, Any]) -> dict[str, Any]:
    """Return only DB-resolved runtime threshold/config/rule data for diagnostics."""
    return {
        "tenantId": policy["tenantId"],
        "erId": policy["erId"],
        "runtimeGenerationId": policy["runtimeGenerationId"],
        "tenantThresholdVersionId": policy["tenantThresholdVersionId"],
        "thresholdVersion": policy["thresholdVersion"],
        "canonicalPolicyHash": policy["canonicalPolicyHash"],
        "noMatchOutcome": policy.get("noMatchOutcome"),
        "effectiveParameterValues": policy.get("effectiveParameterValues") or {},
        "governedRules": policy.get("governedRules") or [],
    }


def print_effective_policy_payload(policy: dict[str, Any]) -> None:
    print(
        "EFFECTIVE_DB_POLICY_JSON="
        + json.dumps(
            effective_policy_payload(policy),
            sort_keys=True,
            separators=(",", ":"),
        )
    )


def print_provenance(policy: dict[str, Any]) -> None:
    runtime = _runtime_config()
    print("RUNTIME_CONFIG_SOURCE=PROCESS_ENV_OR_REPO_CONFIG_OR_PACK_DEFAULT")
    print(f"TENANT_DB_CONFIG_SOURCE={runtime.get('tenant_db_source')}")
    print(f"TENANT_ID_SOURCE={runtime.get('tenant_id_source')}")
    print("THRESHOLD_AUTHORITY=tenant_postgresql")
    print(f"TENANT_ID={policy['tenantId']}")
    print(f"ER_ID={policy['erId']}")
    print(f"RUNTIME_GENERATION_ID={policy['runtimeGenerationId']}")
    print(f"TENANT_THRESHOLD_VERSION_ID={policy['tenantThresholdVersionId']}")
    print(f"THRESHOLD_VERSION={policy['thresholdVersion']}")
    print(f"POLICY_SHA256={policy['canonicalPolicyHash']}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--er", required=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        policy = load_active_policy(args.er)
        if args.json:
            print(json.dumps(policy, indent=2, sort_keys=True))
        else:
            print_provenance(policy)
    except DemoPolicyError as exc:
        print(str(exc), file=__import__("sys").stderr)
        raise SystemExit(2)
