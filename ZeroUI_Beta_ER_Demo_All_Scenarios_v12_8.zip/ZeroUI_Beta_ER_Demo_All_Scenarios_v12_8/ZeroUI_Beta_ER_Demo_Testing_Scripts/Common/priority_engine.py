#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import base64
import fnmatch
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from runtime_policy_db import (DemoPolicyError, list_active_published_er_ids, load_active_policy, load_active_policy_set, print_effective_policy_payload, print_provenance)
from scenario_engine import (
    ScenarioError,
    dynamic_compliant_branch,
    er007_policy,
    er075_profiles,
    er076_config,
    er076_excluded,
    er076_scan_paths,
    er077_threshold,
    evaluate_policy,
    osv_severity,
    write_er075_artifacts,
)

PACK_ROOT = Path(__file__).resolve().parents[1]
STATE_DIR = PACK_ROOT / ".priority-state"
STATE_FILE = STATE_DIR / "active.json"
LIFECYCLE_STATE = PACK_ROOT / ".state" / "active.json"
LIFECYCLE = PACK_ROOT / "Common" / "lifecycle.py"
ENGINE = PACK_ROOT / "Common" / "scenario_engine.py"

PRIORITY_ERS = ("ER-001", "ER-007", "ER-072", "ER-073", "ER-074", "ER-075", "ER-076", "ER-077")
ALLOW_ORDER = ("ER-007", "ER-072", "ER-073", "ER-074", "ER-075", "ER-076", "ER-077", "ER-001")
BLOCK_SCENARIOS = {
    "ER-001": "FILE-COUNT-DENY",
    "ER-007": "RISKY-SQL-DENY",
    "ER-072": "HIGH-CONFIDENCE-DENY",
    "ER-073": "BLOCKED-STATUS-DENY",
    "ER-074": "NONCOMPLIANT-BRANCH-DENY",
    "ER-075": "FAILING-TEST-DENY",
    "ER-076": "BAD-FILENAME-DENY",
    "ER-077": "VULNERABILITY-BREACH-DENY",
}
WARN_SCENARIOS = {
    "ER-001": "LINE-COUNT-REVIEW",
    "ER-007": "RISKY-SQL-CONTROLS-REVIEW",
    "ER-072": "DB-DERIVED-WARN",
}
LEGACY_ER073 = {
    "er073_file_a_test.py": ("test_er073_file_a", "ER-073 skip from file A"),
    "er073_file_b_test.py": ("test_er073_file_b", "ER-073 skip from file B"),
}
EXCLUDED_SCAN_PARTS = {".git", "node_modules", ".venv", "venv", "dist", "build", "__pycache__", PACK_ROOT.name}


class PriorityError(RuntimeError):
    pass


def run(cmd: list[str], *, cwd: Path | None = None, check: bool = True, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    if check and p.returncode != 0:
        raise PriorityError((p.stderr or p.stdout or "COMMAND_FAILED").strip())
    return p


def git(repo: Path, *args: str, check: bool = True) -> str:
    return (run(["git", "-C", str(repo), *args], check=check).stdout or "").strip()


def git_internal_path(repo: Path, relative: str) -> Path:
    raw = git(repo, "rev-parse", "--git-path", relative)
    p = Path(raw)
    return p if p.is_absolute() else (repo / p).resolve()


def repo_root() -> Path:
    p = run(["git", "-C", str(PACK_ROOT), "rev-parse", "--show-toplevel"], check=False)
    if p.returncode != 0 or not (p.stdout or "").strip():
        raise PriorityError("PACK_NOT_INSIDE_GIT_REPOSITORY")
    return Path(p.stdout.strip()).resolve()


def prepared(repo: Path) -> bool:
    try:
        rel = (PACK_ROOT / "README.md").resolve().relative_to(repo.resolve()).as_posix()
    except ValueError:
        return False
    return run(["git", "-C", str(repo), "check-ignore", "-q", "--", rel], check=False).returncode == 0


def changed_paths(repo: Path) -> list[str]:
    out: set[str] = set()
    for args in (("diff", "--name-only", "HEAD"), ("diff", "--cached", "--name-only"), ("ls-files", "--others", "--exclude-standard")):
        for line in git(repo, *args, check=False).splitlines():
            rel = line.strip().replace("\\", "/")
            if rel:
                out.add(rel)
    return sorted(out)


def staged_paths(repo: Path) -> list[str]:
    return sorted({x.strip().replace("\\", "/") for x in git(repo, "diff", "--cached", "--name-only", check=False).splitlines() if x.strip()})


def path_is_tracked(repo: Path, rel: str) -> bool:
    return run(["git", "-C", str(repo), "cat-file", "-e", f"HEAD:{rel}"], check=False).returncode == 0


def remove_untracked(repo: Path, rel: str) -> None:
    p = (repo / rel).resolve()
    try:
        p.relative_to(repo.resolve())
    except ValueError as exc:
        raise PriorityError(f"PATH_OUTSIDE_REPO:{rel}") from exc
    if path_is_tracked(repo, rel):
        raise PriorityError(f"REFUSING_TO_DELETE_TRACKED_FILE:{rel}")
    if p.is_symlink() or p.is_file():
        p.unlink(missing_ok=True)
    elif p.is_dir():
        shutil.rmtree(p)


def path_snapshot(repo: Path, rel: str) -> dict[str, Any]:
    p = (repo / rel).resolve()
    try:
        p.relative_to(repo.resolve())
    except ValueError as exc:
        raise PriorityError(f"PATH_OUTSIDE_REPO:{rel}") from exc
    if p.is_symlink():
        return {"kind": "symlink", "target": os.readlink(p)}
    if not p.exists():
        return {"kind": "absent"}
    if not p.is_file():
        raise PriorityError(f"UNSUPPORTED_DIRTY_PATH_TYPE:{rel}")
    return {"kind": "file", "mode": p.stat().st_mode & 0o777, "data_b64": base64.b64encode(p.read_bytes()).decode("ascii")}


def snapshot_paths(repo: Path, paths: list[str]) -> dict[str, dict[str, Any]]:
    return {rel: path_snapshot(repo, rel) for rel in sorted(set(paths))}


def assert_snapshot_matches(repo: Path, snapshot: dict[str, dict[str, Any]], label: str) -> None:
    changed = [rel for rel, expected in snapshot.items() if path_snapshot(repo, rel) != expected]
    if changed:
        raise PriorityError(f"{label}:{','.join(changed)}")


def restore_snapshot(repo: Path, snapshot: dict[str, dict[str, Any]]) -> None:
    for rel, record in snapshot.items():
        p = (repo / rel).resolve()
        kind = str(record.get("kind") or "")
        if kind == "absent":
            if p.is_symlink() or p.is_file():
                p.unlink(missing_ok=True)
            elif p.is_dir():
                shutil.rmtree(p)
            continue
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.is_symlink() or p.is_file():
            p.unlink(missing_ok=True)
        elif p.is_dir():
            shutil.rmtree(p)
        if kind == "symlink":
            os.symlink(str(record.get("target") or ""), p)
        elif kind == "file":
            p.write_bytes(base64.b64decode(str(record.get("data_b64") or ""), validate=True))
            os.chmod(p, int(record.get("mode") or 0o644))
        else:
            raise PriorityError(f"BASELINE_SNAPSHOT_KIND_INVALID:{rel}={kind}")


def load_state() -> dict[str, Any] | None:
    if not STATE_FILE.is_file():
        return None
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))


def save_state(obj: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(STATE_FILE)


def engine(args: list[str], repo: Path) -> str:
    env = os.environ.copy()
    env["ZEROUI_DEMO_REPO"] = str(repo)
    p = subprocess.run([sys.executable, str(ENGINE), *args], cwd=str(repo), env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.stdout:
        print(p.stdout, end="" if p.stdout.endswith("\n") else "\n")
    if p.returncode != 0:
        raise PriorityError((p.stderr or p.stdout or "SCENARIO_ENGINE_FAILED").strip())
    return p.stdout or ""


def dynamic_noncompliant_branch(token: str, repo: Path) -> str:
    out = engine(["branch", "--mode", "noncompliant", "--token", token], repo)
    vals = [x.split("=", 1)[1].strip() for x in out.splitlines() if x.startswith("BRANCH_NAME=")]
    if len(vals) != 1:
        raise PriorityError("NONCOMPLIANT_BRANCH_UNRESOLVED")
    return vals[0]


def active_published_priority() -> list[str]:
    ids = set(list_active_published_er_ids())
    return [er for er in PRIORITY_ERS if er in ids]


def delete_branch_if_exists(repo: Path, branch: str) -> None:
    if branch and run(["git", "-C", str(repo), "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"], check=False).returncode == 0:
        git(repo, "branch", "-D", branch, check=False)


def restore_priority_state(state: dict[str, Any], verify_current: bool = True) -> None:
    repo = Path(str(state["repo_root"])).resolve()
    post = state.get("post_simulation_snapshot") or {}
    if verify_current and post:
        assert_snapshot_matches(repo, post, "PRIORITY_STATE_CHANGED_EXTERNALLY")
    baseline = state.get("baseline_snapshot") or {}
    # Restore paths known by transaction.
    for rel in sorted(set(state.get("changed_paths") or []) | set(baseline.keys()), key=lambda x: (x.count("/"), x), reverse=True):
        if rel in baseline:
            continue
        if path_is_tracked(repo, rel):
            git(repo, "restore", "--source=HEAD", "--staged", "--worktree", "--", rel, check=False)
        else:
            remove_untracked(repo, rel)
    original_branch = str(state.get("original_branch") or "")
    original_commit = str(state.get("original_commit") or "")
    demo_branch = str(state.get("demo_branch") or "")
    current = git(repo, "branch", "--show-current", check=False)
    if original_branch:
        if current != original_branch:
            git(repo, "switch", original_branch)
    elif original_commit:
        git(repo, "switch", "--detach", original_commit)
    if demo_branch and demo_branch != original_branch:
        delete_branch_if_exists(repo, demo_branch)
    restore_snapshot(repo, baseline)
    if STATE_DIR.exists():
        shutil.rmtree(STATE_DIR)


def restore_active_individual_demo(repo: Path) -> bool:
    if not LIFECYCLE_STATE.is_file():
        return False
    q = subprocess.run([sys.executable, str(LIFECYCLE), "restore"], cwd=str(repo), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if q.stdout:
        print(q.stdout, end="" if q.stdout.endswith("\n") else "\n")
    if q.returncode != 0:
        raise PriorityError((q.stderr or q.stdout or "INDIVIDUAL_DEMO_RESTORE_FAILED").strip())
    return True


def backup_file(repo: Path, rel: str, backup_root: Path) -> None:
    p = repo / rel
    dest = backup_root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if p.is_file():
        shutil.copy2(p, dest)
    else:
        marker = dest.with_suffix(dest.suffix + ".ABSENT")
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text("absent\n", encoding="utf-8")


def remove_known_generated(repo: Path, patterns: tuple[str, ...], *, label: str) -> list[str]:
    matches: list[tuple[Path, str]] = []
    for p in repo.rglob("*"):
        if not (p.is_file() or p.is_dir()):
            continue
        try:
            rel = p.relative_to(repo).as_posix()
        except ValueError:
            continue
        if any(part in EXCLUDED_SCAN_PARTS for part in Path(rel).parts):
            continue
        name = p.name
        if any(fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel, pat) for pat in patterns):
            matches.append((p, rel))
    removed: list[str] = []
    for p, rel in sorted(matches, key=lambda x: (x[1].count("/"), x[1]), reverse=True):
        if not p.exists() and not p.is_symlink():
            continue
        if path_is_tracked(repo, rel):
            raise PriorityError(f"{label}_GENERATED_NAME_IS_TRACKED_REFUSED:{rel}")
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink(missing_ok=True)
        removed.append(rel)
    return sorted(set(removed))


def remove_er076_generated(repo: Path, policy: dict[str, Any]) -> list[str]:
    cfg = er076_config(policy)
    generated_name = re.compile(r"^(?:zeroui_bad_[0-9a-f]{8}|BAD-[0-9a-f]{8}|[0-9a-f]{8}\.txt)\.sql$", re.I)
    removed: list[str] = []
    for p in list(er076_scan_paths(repo, cfg)):
        rel = p.relative_to(repo).as_posix()
        if er076_excluded(rel, cfg) or not generated_name.fullmatch(p.name):
            continue
        if path_is_tracked(repo, rel):
            raise PriorityError(f"ER076_GENERATED_NAME_IS_TRACKED_REFUSED:{rel}")
        p.unlink(missing_ok=True)
        removed.append(rel)
    return sorted(set(removed))


def _dotted(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        left = _dotted(node.value)
        return f"{left}.{node.attr}" if left else node.attr
    if isinstance(node, ast.Call):
        return _dotted(node.func)
    return ""


def _is_skip(name: str) -> bool:
    v = name.lower()
    return v == "pytest.skip" or v == "unittest.skip" or v.endswith(".mark.skip") or v.endswith(".mark.skipif") or v.endswith(".skip") or v.endswith(".skipif")


def remove_owned_er073_fixture(repo: Path) -> bool:
    rel = "test_zeroui_er073_demo.py"
    p = repo / rel
    if not p.is_file():
        return False
    text = p.read_text(encoding="utf-8", errors="ignore")
    if "# ZEROUI_ER073_DEMO_OWNED" not in text:
        raise PriorityError("ER073_DEMO_FILENAME_EXISTS_WITHOUT_OWNERSHIP_MARKER")
    if path_is_tracked(repo, rel):
        raise PriorityError("ER073_DEMO_OWNED_FILE_IS_TRACKED_REFUSED")
    p.unlink()
    return True


def remediate_legacy_er073(repo: Path) -> list[str]:
    changed: list[str] = []
    backup = git_internal_path(repo, "zeroui-er073-legacy-backups") / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup.mkdir(parents=True, exist_ok=True)
    for filename, (test_name, reason) in LEGACY_ER073.items():
        path = repo / filename
        if not path.is_file():
            continue
        source = path.read_text(encoding="utf-8")
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            raise PriorityError(f"ER073_LEGACY_PARSE_FAILED:{filename}:{exc.lineno}:{exc.msg}") from exc
        targets = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == test_name]
        if len(targets) != 1:
            continue
        target = targets[0]
        lines = source.splitlines(keepends=True)
        removals: list[tuple[int, int]] = []
        for dec in target.decorator_list:
            name = _dotted(dec)
            if not _is_skip(name):
                continue
            a = dec.lineno - 1
            b = getattr(dec, "end_lineno", dec.lineno)
            if reason not in "".join(lines[a:b]):
                raise PriorityError(f"ER073_UNKNOWN_SKIP_DECORATOR_REFUSED:{filename}:{name}")
            removals.append((a, b))
        for stmt in target.body:
            if not (isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call)):
                continue
            name = _dotted(stmt.value.func)
            if name not in {"pytest.skip", "unittest.skip"}:
                continue
            a = stmt.lineno - 1
            b = getattr(stmt, "end_lineno", stmt.lineno)
            if reason not in "".join(lines[a:b]):
                raise PriorityError(f"ER073_UNKNOWN_SKIP_CALL_REFUSED:{filename}:{name}")
            removals.append((a, b))
        if not removals:
            continue
        shutil.copy2(path, backup / filename)
        for a, b in sorted(set(removals), reverse=True):
            del lines[a:b]
        patched = "".join(lines)
        ast.parse(patched)
        path.write_text(patched, encoding="utf-8")
        changed.append(filename)
    if changed:
        print(f"ER073_LEGACY_BACKUP_DIR={backup}")
    else:
        try:
            backup.rmdir()
            backup.parent.rmdir()
        except Exception:
            pass
    return changed


def scan_remaining_er073(repo: Path, policy: dict[str, Any]) -> list[str]:
    rules = policy["effectiveParameterValues"].get("semantic_detection_rules")
    pytest_skip_enabled = False
    if isinstance(rules, list):
        for row in rules:
            if not isinstance(row, dict) or row.get("enabled") is not True:
                continue
            if (
                str(row.get("language") or "").lower() == "python"
                and str(row.get("framework") or "").lower() == "pytest"
                and str(row.get("construct") or "") == "pytest.mark.skip"
            ):
                pytest_skip_enabled = True
    if not pytest_skip_enabled:
        return []
    findings: list[str] = []
    for p in repo.rglob("*.py"):
        rel = p.relative_to(repo).as_posix()
        if any(part in EXCLUDED_SCAN_PARTS for part in Path(rel).parts):
            continue
        if not (p.name.startswith("test_") or p.name.endswith("_test.py")):
            continue
        try:
            tree = ast.parse(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and _is_skip(_dotted(node.func)):
                findings.append(f"{rel}:{getattr(node, 'lineno', 0)}:{_dotted(node.func)}")
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                for dec in node.decorator_list:
                    if _is_skip(_dotted(dec)):
                        findings.append(f"{rel}:{getattr(dec, 'lineno', 0)}:{_dotted(dec)}")
    return sorted(set(findings))


def er007_scoped_files(repo: Path, cfg: dict[str, Any]) -> list[Path]:
    scans = cfg.get("scan_folders")
    if not isinstance(scans, list) or not scans:
        raise PriorityError("ER007_DB_SCAN_FOLDERS_MISSING")
    out: list[Path] = []
    for p in repo.rglob("*.sql"):
        rel = p.relative_to(repo).as_posix()
        if any(part in EXCLUDED_SCAN_PARTS for part in Path(rel).parts):
            continue
        for raw in scans:
            s = str(raw).replace("\\", "/")
            if fnmatch.fnmatch(rel, s) or Path(rel).match(s) or (not any(c in s for c in "*?[") and (rel == s.rstrip("/") or rel.startswith(s.rstrip("/") + "/"))):
                out.append(p)
                break
    return sorted(set(out))


def er007_risky_findings(repo: Path, policy: dict[str, Any]) -> list[str]:
    cfg = er007_policy(policy)
    risky = cfg.get("risky_sql")
    if not isinstance(risky, list):
        raise PriorityError("ER007_DB_RISKY_SQL_MISSING")
    findings: list[str] = []
    for p in er007_scoped_files(repo, cfg):
        text = p.read_text(encoding="utf-8", errors="ignore")
        for row in risky:
            if not isinstance(row, dict):
                continue
            hit = False
            if isinstance(row.get("find"), str) and row["find"].strip() and row["find"].lower() in text.lower():
                hit = True
            if isinstance(row.get("find_regex"), str) and row["find_regex"].strip() and re.search(row["find_regex"], text, re.I | re.M):
                hit = True
            if hit:
                findings.append(p.relative_to(repo).as_posix())
                break
    return sorted(set(findings))


def iter_text_files(repo: Path):
    for p in repo.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(repo).as_posix()
        if any(part in EXCLUDED_SCAN_PARTS for part in Path(rel).parts):
            continue
        try:
            if p.stat().st_size > 2_000_000:
                continue
            data = p.read_bytes()
            if b"\x00" in data[:4096]:
                continue
            yield rel, data.decode("utf-8", errors="ignore")
        except Exception:
            continue


def er072_findings(repo: Path, policy: dict[str, Any]) -> list[str]:
    rules = policy["effectiveParameterValues"].get("detection_rules")
    if not isinstance(rules, list):
        raise PriorityError("ER072_DB_DETECTION_RULES_MISSING")
    compiled: list[tuple[str, str, Any]] = []
    for row in rules:
        if not isinstance(row, dict):
            continue
        confidence = str(row.get("confidence") or "unknown").lower()
        rtype = str(row.get("type") or "")
        if rtype == "regex" and isinstance(row.get("pattern"), str) and row["pattern"]:
            compiled.append((confidence, rtype, re.compile(str(row["pattern"]))))
        elif rtype == "sensitive_key_value" and isinstance(row.get("key_pattern"), str) and row["key_pattern"]:
            kp = str(row["key_pattern"])
            min_len = int(row.get("min_length") or 1)
            compiled.append((confidence, rtype, (re.compile(kp, re.I), min_len)))
    findings: list[str] = []
    for rel, text in iter_text_files(repo):
        for confidence, rtype, spec in compiled:
            if rtype == "regex":
                if spec.search(text):
                    findings.append(f"{rel}:{confidence}:regex")
                    break
            else:
                key_re, min_len = spec
                for line in text.splitlines():
                    m = re.match(r"\s*([^:=\s]+)\s*[:=]\s*[\"']?([^\"'\s#]+)", line)
                    if not m:
                        continue
                    if key_re.search(m.group(1)) and len(m.group(2)) >= min_len:
                        findings.append(f"{rel}:{confidence}:sensitive_key_value")
                        break
                if findings and findings[-1].startswith(rel + ":"):
                    break
    return sorted(set(findings))


def branch_matches_policy(branch: str, policy: dict[str, Any]) -> bool:
    pats = policy["effectiveParameterValues"].get("allowed_patterns")
    if not isinstance(pats, list) or not pats:
        raise PriorityError("ER074_DB_ALLOWED_PATTERNS_MISSING")
    for raw in pats:
        try:
            if re.fullmatch(str(raw), branch) or re.search(str(raw), branch):
                return True
        except re.error as exc:
            raise PriorityError(f"ER074_DB_PATTERN_INVALID:{raw}:{exc}") from exc
    return False


def ensure_compliant_branch(repo: Path, policy: dict[str, Any], token: str) -> str:
    current = git(repo, "branch", "--show-current", check=False)
    if current and branch_matches_policy(current, policy):
        return current
    target = dynamic_compliant_branch(token)
    if not branch_matches_policy(target, policy):
        raise PriorityError(f"ER074_GENERATED_BRANCH_NOT_COMPLIANT:{target}")
    if run(["git", "-C", str(repo), "show-ref", "--verify", "--quiet", f"refs/heads/{target}"], check=False).returncode == 0:
        git(repo, "switch", target)
    else:
        git(repo, "switch", "-c", target)
    return target


def er076_bad_paths(repo: Path, policy: dict[str, Any]) -> list[str]:
    cfg = er076_config(policy)
    pats_raw = cfg.get("allowed_name_patterns")
    if not isinstance(pats_raw, list) or not pats_raw:
        raise PriorityError("ER076_DB_ALLOWED_NAME_PATTERNS_MISSING")
    pats = [re.compile(str(x)) for x in pats_raw]
    bad: list[str] = []
    for p in er076_scan_paths(repo, cfg):
        rel = p.relative_to(repo).as_posix()
        if er076_excluded(rel, cfg):
            continue
        if not any(rx.search(p.name) for rx in pats):
            bad.append(rel)
    return sorted(set(bad))


def restore_er077_demo_package(repo: Path, backup_root: Path) -> bool:
    pj = repo / "package.json"
    if not pj.is_file():
        return False
    try:
        obj = json.loads(pj.read_text(encoding="utf-8"))
    except Exception:
        return False
    if obj.get("name") != "zeroui-er077-demo":
        return False
    for rel in ("package.json", "package-lock.json"):
        backup_file(repo, rel, backup_root)
        if path_is_tracked(repo, rel):
            git(repo, "restore", "--source=HEAD", "--worktree", "--", rel)
        else:
            remove_untracked(repo, rel)
    return True


def osv_query_version(name: str, version: str) -> dict[str, Any]:
    payload = json.dumps({"package": {"name": name, "ecosystem": "npm"}, "version": version}).encode()
    req = urllib.request.Request("https://api.osv.dev/v1/query", data=payload, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode())
    except Exception as exc:
        raise PriorityError(f"ER077_OSV_QUERY_FAILED:{name}@{version}:{exc}") from exc


def er077_policy_breaches(repo: Path, policy: dict[str, Any]) -> list[str]:
    cfg, order, threshold = er077_threshold(policy)
    ti = order.index(threshold)
    include_direct = cfg.get("include_direct_dependencies") is True
    include_transitive = cfg.get("include_transitive_dependencies") is True
    deps: dict[str, str] = {}
    package = repo / "package.json"
    lock = repo / "package-lock.json"
    if include_direct and package.is_file():
        try:
            obj = json.loads(package.read_text(encoding="utf-8"))
            for sec in ("dependencies", "devDependencies"):
                if isinstance(obj.get(sec), dict):
                    for name, ver in obj[sec].items():
                        if isinstance(ver, str) and re.fullmatch(r"\d+\.\d+\.\d+(?:[-+].*)?", ver.strip()):
                            deps[name] = ver.strip()
        except Exception as exc:
            raise PriorityError(f"ER077_PACKAGE_JSON_INVALID:{exc}") from exc
    if include_transitive and lock.is_file():
        try:
            obj = json.loads(lock.read_text(encoding="utf-8"))
            packages = obj.get("packages")
            if isinstance(packages, dict):
                for key, meta in packages.items():
                    if not key.startswith("node_modules/") or not isinstance(meta, dict):
                        continue
                    name = key.split("node_modules/", 1)[1]
                    ver = meta.get("version")
                    if isinstance(ver, str) and ver.strip():
                        deps[name] = ver.strip()
        except Exception as exc:
            raise PriorityError(f"ER077_PACKAGE_LOCK_INVALID:{exc}") from exc
    breaches: list[str] = []
    for name, version in sorted(deps.items()):
        data = osv_query_version(name, version)
        for vuln in data.get("vulns") or []:
            if not isinstance(vuln, dict) or vuln.get("withdrawn"):
                continue
            sev = osv_severity(vuln)
            if sev in order and order.index(sev) >= ti:
                breaches.append(f"{name}@{version}:{sev}:{vuln.get('id', 'unknown')}")
                break
    return breaches


def git_change_facts(repo: Path) -> dict[str, int]:
    paths = changed_paths(repo)
    files_changed = len(paths)
    lines_changed = 0
    tracked_numstat = git(repo, "diff", "--numstat", "HEAD", check=False)
    tracked_set: set[str] = set()
    for line in tracked_numstat.splitlines():
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        a, d, rel = parts[0], parts[1], parts[-1]
        tracked_set.add(rel.replace("\\", "/"))
        if a.isdigit():
            lines_changed += int(a)
        if d.isdigit():
            lines_changed += int(d)
    for rel in paths:
        if rel in tracked_set:
            continue
        p = repo / rel
        if p.is_file():
            try:
                lines_changed += len(p.read_text(encoding="utf-8", errors="ignore").splitlines())
            except Exception:
                lines_changed += 1
    # Conservative upper bound: number of services/modules touched cannot exceed files changed.
    return {"files_changed": files_changed, "lines_changed": lines_changed, "services_modules_touched": files_changed}


def print_er_header(er: str, index: int, total: int, policy: dict[str, Any]) -> None:
    print()
    print(f"ALLOW_ER_SEQUENCE={index}/{total}:{er}")
    print_provenance(policy)


def remediate_all_to_allow(repo: Path) -> None:
    published = active_published_priority()
    missing = [er for er in PRIORITY_ERS if er not in published]
    if missing:
        raise PriorityError("BETA_ER_NOT_ACTIVE_PUBLISHED:" + ",".join(missing))

    # Resolve all eight policies from one exact active runtime generation before
    # changing anything. No "latest published", local threshold, or built-in
    # threshold fallback is allowed.
    policies = load_active_policy_set(PRIORITY_ERS)
    generation_ids = {str(p["runtimeGenerationId"]) for p in policies.values()}
    if len(generation_ids) != 1:
        raise PriorityError("ACTIVE_RUNTIME_GENERATION_INCONSISTENT_ACROSS_BETA_ERS")

    print("PRIORITY_SCOPE=" + ",".join(PRIORITY_ERS))
    print("ALLOW_METHOD=ER_BY_ER_ACTIVE_DB_POLICY")
    print("THRESHOLD_AUTHORITY=tenant_postgresql")
    print("THRESHOLD_VALUES_HARDCODED=NO")
    print("LATEST_PUBLISHED_SELECTION=NO")
    print("LOCAL_THRESHOLD_FALLBACK=NO")
    print("DEFAULT_THRESHOLD_FALLBACK=NO")
    print("EXTENSION_MUTATION=NO")
    print("VSIX_MUTATION=NO")
    print("ACTIVE_RUNTIME_GENERATION_ID=" + next(iter(generation_ids)))

    # Print the exact DB-effective policy used for each ER before repository mutation.
    for er_id in PRIORITY_ERS:
        print(f"DB_POLICY_RESOLUTION_BEGIN={er_id}")
        print_provenance(policies[er_id])
        print_effective_policy_payload(policies[er_id])
        print(f"DB_POLICY_RESOLUTION_END={er_id}")

    # First restore package-owned transaction state, because those mutations are known exactly.
    state = load_state()
    if state:
        if Path(str(state.get("repo_root") or "")).resolve() != repo:
            raise PriorityError("PRIORITY_STATE_REPO_MISMATCH")
        restore_priority_state(state)
        print("PRIORITY_TRANSACTION_ROLLBACK=PASS")
    else:
        print("PRIORITY_TRANSACTION_ROLLBACK=NO_ACTIVE_TRANSACTION")

    if restore_active_individual_demo(repo):
        print("INDIVIDUAL_DEMO_ROLLBACK=PASS")
    else:
        print("INDIVIDUAL_DEMO_ROLLBACK=NO_ACTIVE_TRANSACTION")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_root = git_internal_path(repo, "zeroui-policy-allow-backups") / stamp
    backup_root.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex[:8]

    for idx, er in enumerate(ALLOW_ORDER, start=1):
        policy = policies[er]
        print_er_header(er, idx, len(ALLOW_ORDER), policy)

        if er == "ER-007":
            removed = remove_known_generated(repo, ("zeroui_er007_demo_*.sql",), label="ER007")
            print("ER007_DEMO_FILES_REMOVED=" + (",".join(removed) if removed else "NONE"))
            risky = er007_risky_findings(repo, policy)
            if risky:
                raise PriorityError("ER007_NON_ALLOW_EVIDENCE_REMAINS:" + ",".join(risky[:20]))
            print("ER007_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-072":
            removed = remove_known_generated(repo, ("zeroui-er072-*.env", "zeroui-er072-*.txt"), label="ER072")
            print("ER072_DEMO_FILES_REMOVED=" + (",".join(removed) if removed else "NONE"))
            findings = er072_findings(repo, policy)
            if findings:
                raise PriorityError("ER072_POLICY_DETECTION_REMAINS:" + ",".join(findings[:20]))
            print("ER072_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-073":
            print("ER073_DEMO_FIXTURE_REMOVED=YES" if remove_owned_er073_fixture(repo) else "ER073_DEMO_FIXTURE_REMOVED=NOT_PRESENT")
            legacy = remediate_legacy_er073(repo)
            print("ER073_LEGACY_REMEDIATED=" + (",".join(legacy) if legacy else "NONE"))
            remaining = scan_remaining_er073(repo, policy)
            if remaining:
                raise PriorityError("ER073_SKIP_EVIDENCE_REMAINS:" + ",".join(remaining[:20]))
            print("ER073_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-074":
            before = git(repo, "branch", "--show-current", check=False) or "DETACHED"
            after = ensure_compliant_branch(repo, policy, token)
            print(f"ER074_BRANCH_BEFORE={before}")
            print(f"ER074_BRANCH_AFTER={after}")
            print("ER074_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-075":
            for profile in er075_profiles(policy):
                ev = profile.get("evidence")
                if not isinstance(ev, dict) or ev.get("source") != "artifact" or not ev.get("configuredLocation"):
                    raise PriorityError(f"ER075_PROFILE_UNSUPPORTED_FOR_ALLOW:{profile.get('id')}")
                rel = str(ev["configuredLocation"])
                backup_file(repo, rel, backup_root)
            write_er075_artifacts(repo, policy, "passed", "allow-" + token)
            print("ER075_DB_CONFIGURED_TEST_ARTIFACTS=PASSED")
            print("ER075_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-076":
            removed = remove_er076_generated(repo, policy)
            print("ER076_DEMO_FILES_REMOVED=" + (",".join(removed) if removed else "NONE"))
            bad = er076_bad_paths(repo, policy)
            if bad:
                raise PriorityError("ER076_NONCOMPLIANT_MIGRATION_REMAINS:" + ",".join(bad[:20]))
            print("ER076_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-077":
            restored = restore_er077_demo_package(repo, backup_root)
            print("ER077_SYNTHETIC_PACKAGE_RESTORED_FROM_HEAD=YES" if restored else "ER077_SYNTHETIC_PACKAGE_RESTORED_FROM_HEAD=NOT_PRESENT")
            breaches = er077_policy_breaches(repo, policy)
            if breaches:
                raise PriorityError("ER077_THRESHOLD_BREACH_REMAINS:" + ",".join(breaches[:20]))
            print("ER077_POLICY_ALLOW_PRECHECK=PASS")

        elif er == "ER-001":
            removed = remove_known_generated(repo, ("zeroui-er001-files-*", "zeroui-er001-lines-*.txt"), label="ER001")
            print("ER001_DEMO_FILES_REMOVED=" + (",".join(removed) if removed else "NONE"))
            facts = git_change_facts(repo)
            outcome = evaluate_policy(policy, facts)
            print("ER001_FILES_CHANGED=" + str(facts["files_changed"]))
            print("ER001_LINES_CHANGED=" + str(facts["lines_changed"]))
            print("ER001_SERVICES_MODULES_TOUCHED_CONSERVATIVE=" + str(facts["services_modules_touched"]))
            print("ER001_DB_POLICY_OUTCOME_CONSERVATIVE=" + str(outcome))
            if outcome != "allow":
                raise PriorityError("ER001_ACTIVE_POLICY_NOT_ALLOW_AFTER_ROLLBACK")
            print("ER001_POLICY_ALLOW_PRECHECK=PASS")

    # Remove empty backup dir if nothing was backed up.
    try:
        if backup_root.exists() and not any(backup_root.rglob("*")):
            backup_root.rmdir()
            backup_root.parent.rmdir()
    except Exception:
        pass

    print()
    print("ALL_8_ER_POLICY_ALLOW_PRECHECK=PASS")
    print("ROLLBACK_SEQUENCE_COMPLETE=YES")
    print("FINAL_GOVERNED_STATE_CLAIM=NO")
    print("FINAL_VERIFICATION=Run existing ZeroUI Check Current Context once. The installed product remains authoritative.")
    if backup_root.exists():
        print(f"ALLOW_BACKUP_DIR={backup_root}")



def governed_outcomes(policy: dict[str, Any]) -> set[str]:
    outcomes: set[str] = set()
    no_match = str(policy.get("noMatchOutcome") or "").strip()
    if no_match:
        outcomes.add(no_match)
    for rule in policy.get("governedRules") or []:
        if not isinstance(rule, dict):
            continue
        outcome = str(rule.get("outcome") or "").strip()
        if outcome:
            outcomes.add(outcome)
    return outcomes


def print_policy_set_for_simulation(
    policies: dict[str, dict[str, Any]],
    *,
    operation: str,
) -> None:
    generations = {str(p.get("runtimeGenerationId") or "") for p in policies.values()}
    if len(generations) != 1:
        raise PriorityError(
            f"{operation.upper()}_ACTIVE_RUNTIME_GENERATION_INCONSISTENT"
        )

    print(f"{operation.upper()}_METHOD=ER_BY_ER_ACTIVE_DB_POLICY")
    print("THRESHOLD_AUTHORITY=tenant_postgresql")
    print("THRESHOLD_VALUES_HARDCODED=NO")
    print("THRESHOLD_LOAD_MODE=DYNAMIC_ON_EVERY_RUN")
    print("LATEST_PUBLISHED_SELECTION=NO")
    print("LOCAL_THRESHOLD_FALLBACK=NO")
    print("DEFAULT_THRESHOLD_FALLBACK=NO")
    print("ACTIVE_RUNTIME_GENERATION_ID=" + next(iter(generations)))

    for er in policies:
        print(f"DB_POLICY_RESOLUTION_BEGIN={er}")
        print_provenance(policies[er])
        print_effective_policy_payload(policies[er])
        print(f"DB_POLICY_RESOLUTION_END={er}")


def begin_simulation_transaction(
    repo: Path,
    *,
    mode: str,
) -> dict[str, Any]:
    state = load_state()
    if state:
        if Path(str(state.get("repo_root") or "")).resolve() != repo:
            raise PriorityError("PRIORITY_STATE_REPO_MISMATCH")
        if str(state.get("mode") or "") != mode:
            raise PriorityError(
                f"PRIORITY_STATE_MODE_MISMATCH:"
                f"active={state.get('mode')} requested={mode}; run Allow first"
            )
        post = state.get("post_simulation_snapshot") or {}
        if post:
            assert_snapshot_matches(
                repo,
                post,
                "PRIORITY_STATE_CHANGED_EXTERNALLY",
            )
        return state

    staged = staged_paths(repo)
    if staged:
        raise PriorityError("STAGED_CHANGES_UNSUPPORTED:" + ",".join(staged))

    dirty = changed_paths(repo)
    baseline = snapshot_paths(repo, dirty)
    state = {
        "schema_version": "5.0.0",
        "mode": mode,
        "repo_root": str(repo),
        "token": uuid.uuid4().hex[:8],
        "original_branch": git(
            repo,
            "symbolic-ref",
            "--quiet",
            "--short",
            "HEAD",
            check=False,
        ),
        "original_commit": git(repo, "rev-parse", "HEAD"),
        "changed_paths": list(dirty),
        "demo_branch": "",
        "targets": [],
        "baseline_snapshot": baseline,
        "post_simulation_snapshot": snapshot_paths(repo, dirty),
    }
    save_state(state)
    return state


def record_simulation_target(
    repo: Path,
    state: dict[str, Any],
    er: str,
) -> None:
    baseline = state.get("baseline_snapshot") or {}
    if baseline:
        assert_snapshot_matches(
            repo,
            baseline,
            f"PREEXISTING_WORKSPACE_PATH_MODIFIED_BY_{er}",
        )
    state["changed_paths"] = changed_paths(repo)
    state["targets"] = sorted(set(state.get("targets") or []) | {er})
    state["post_simulation_snapshot"] = snapshot_paths(
        repo,
        list(state["changed_paths"]),
    )
    save_state(state)


def simulate_warn_from_active_policy() -> None:
    repo = repo_root()
    if not prepared(repo):
        raise PriorityError("RUN_PREPARE_FIRST")
    if LIFECYCLE_STATE.is_file():
        raise PriorityError("ACTIVE_INDIVIDUAL_DEMO_EXISTS")

    published = active_published_priority()
    if not published:
        raise PriorityError("NO_PUBLISHED_PRIORITY_ERS")

    policies = load_active_policy_set(tuple(published))
    print("PRIORITY_SCOPE=" + ",".join(PRIORITY_ERS))
    print("PUBLISHED_PRIORITY_ERS=" + ",".join(published))
    print_policy_set_for_simulation(policies, operation="warn")
    print("OPERATION_MODE=REPO_ONLY")
    print("EXTENSION_MUTATION=NO")
    print("VSIX_MUTATION=NO")

    warn_targets: list[str] = []
    no_warn_lane: list[str] = []

    for er in published:
        outcomes = governed_outcomes(policies[er])
        if "human_review_required" in outcomes:
            if er not in WARN_SCENARIOS:
                raise PriorityError(
                    "ACTIVE_DB_WARN_OUTCOME_HAS_NO_SAFE_REPO_SIMULATOR:"
                    f"{er}"
                )
            warn_targets.append(er)
        else:
            no_warn_lane.append(er)

    print(
        "WARN_TARGETS="
        + (",".join(warn_targets) if warn_targets else "NONE")
    )
    print(
        "NO_WARN_OUTCOME_IN_ACTIVE_POLICY="
        + (",".join(no_warn_lane) if no_warn_lane else "NONE")
    )

    if not warn_targets:
        print("REPO_ONLY_WARN_SIMULATION=NO_ACTIVE_WARN_LANES")
        print("FINAL_GOVERNED_STATE_CLAIM=NO")
        return

    state = begin_simulation_transaction(repo, mode="warn")
    already = set(state.get("targets") or [])
    targets = [er for er in warn_targets if er not in already]

    try:
        token = str(state["token"])
        for er in [x for x in PRIORITY_ERS if x in targets]:
            print(f"WARN_SIMULATION_BEGIN={er}")
            print_provenance(policies[er])
            print_effective_policy_payload(policies[er])

            engine(
                [
                    "prepare",
                    "--repo",
                    str(repo),
                    "--er",
                    er,
                    "--token",
                    token,
                ],
                repo,
            )
            engine(
                [
                    "apply",
                    "--repo",
                    str(repo),
                    "--er",
                    er,
                    "--scenario",
                    WARN_SCENARIOS[er],
                    "--token",
                    token,
                ],
                repo,
            )
            record_simulation_target(repo, state, er)
            print(f"WARN_SIMULATION_END={er}")

        print(
            "PACKAGE_WARN_EVIDENCE_CREATED_FOR="
            + (",".join(targets) if targets else "NONE_NEW")
        )
        print("REPO_ONLY_WARN_SIMULATION=PASS")
        print("THRESHOLD_VALUES_HARDCODED=NO")
        print("FINAL_GOVERNED_STATE_CLAIM=NO")
    except Exception:
        current = load_state()
        if current:
            try:
                current["changed_paths"] = changed_paths(repo)
                restore_priority_state(current, verify_current=False)
            except Exception:
                pass
        raise



def block_published_repo_only() -> None:
    repo = repo_root()
    if not prepared(repo):
        raise PriorityError("RUN_PREPARE_FIRST")
    if LIFECYCLE_STATE.is_file():
        raise PriorityError("ACTIVE_INDIVIDUAL_DEMO_EXISTS")

    published = active_published_priority()
    if not published:
        raise PriorityError("NO_PUBLISHED_PRIORITY_ERS")

    # Resolve every target from one exact active runtime generation before any
    # repo mutation. No threshold or "latest published" fallback exists.
    policies = load_active_policy_set(tuple(published))

    print("PRIORITY_SCOPE=" + ",".join(PRIORITY_ERS))
    print("PUBLISHED_PRIORITY_ERS=" + ",".join(published))
    print_policy_set_for_simulation(policies, operation="block")
    print("OPERATION_MODE=REPO_ONLY")
    print("EXTENSION_MUTATION=NO")
    print("VSIX_MUTATION=NO")

    block_targets: list[str] = []
    for er in published:
        outcomes = governed_outcomes(policies[er])
        if "deny" in outcomes:
            block_targets.append(er)
            continue
        if "incident_workflow" in outcomes:
            # The repo simulator currently certifies deterministic DENY fixtures.
            # Do not silently substitute a different hard-block lane.
            raise PriorityError(
                "ACTIVE_DB_BLOCK_OUTCOME_UNSUPPORTED_BY_SAFE_REPO_SIMULATOR:"
                f"{er}:incident_workflow"
            )
        raise PriorityError(
            "ACTIVE_DB_POLICY_HAS_NO_DENY_BLOCK_LANE:"
            f"{er}:outcomes={sorted(outcomes)}"
        )

    state = begin_simulation_transaction(repo, mode="block")
    already = set(state.get("targets") or [])
    targets = [er for er in block_targets if er not in already]

    print(
        "BLOCK_TARGETS="
        + (",".join(targets) if targets else "NONE")
    )

    if not targets:
        print("REPO_ONLY_BLOCK_SIMULATION=PASS")
        print("ALL_DB_DERIVED_BLOCK_TARGETS_ALREADY_ACTIVE=YES")
        print("FINAL_GOVERNED_STATE_CLAIM=NO")
        return

    try:
        token = str(state["token"])

        if "ER-074" in targets and not state.get("demo_branch"):
            branch = dynamic_noncompliant_branch(token, repo)
            if run(
                [
                    "git",
                    "-C",
                    str(repo),
                    "show-ref",
                    "--verify",
                    "--quiet",
                    f"refs/heads/{branch}",
                ],
                check=False,
            ).returncode == 0:
                raise PriorityError(f"DEMO_BRANCH_ALREADY_EXISTS:{branch}")
            git(repo, "switch", "-c", branch)
            state["demo_branch"] = branch
            save_state(state)

        for er in [x for x in PRIORITY_ERS if x in targets]:
            print(f"BLOCK_SIMULATION_BEGIN={er}")
            print_provenance(policies[er])
            print_effective_policy_payload(policies[er])

            engine(
                [
                    "prepare",
                    "--repo",
                    str(repo),
                    "--er",
                    er,
                    "--token",
                    token,
                ],
                repo,
            )
            engine(
                [
                    "apply",
                    "--repo",
                    str(repo),
                    "--er",
                    er,
                    "--scenario",
                    BLOCK_SCENARIOS[er],
                    "--token",
                    token,
                ],
                repo,
            )
            record_simulation_target(repo, state, er)
            print(f"BLOCK_SIMULATION_END={er}")

        print("PACKAGE_BLOCK_EVIDENCE_CREATED_FOR=" + ",".join(targets))
        print("REPO_ONLY_BLOCK_SIMULATION=PASS")
        print("THRESHOLD_VALUES_HARDCODED=NO")
        print("FINAL_GOVERNED_STATE_CLAIM=NO")
    except Exception:
        current = load_state()
        if current:
            try:
                current["changed_paths"] = changed_paths(repo)
                restore_priority_state(current, verify_current=False)
            except Exception:
                pass
        raise

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["allow", "warn", "block"])
    args = ap.parse_args()
    try:
        repo = repo_root()
        if args.action == "allow":
            remediate_all_to_allow(repo)
        elif args.action == "warn":
            simulate_warn_from_active_policy()
        else:
            block_published_repo_only()
        return 0
    except (PriorityError, DemoPolicyError, ScenarioError, SyntaxError) as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
