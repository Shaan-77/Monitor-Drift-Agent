#!/usr/bin/env python3
from __future__ import annotations

import argparse
import fnmatch
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import urllib.error
import uuid
from pathlib import Path
from typing import Any

from runtime_policy_db import DemoPolicyError, load_active_policy, print_provenance


class ScenarioError(RuntimeError):
    pass


def git(repo: Path, *args: str, check: bool = True) -> str:
    p = subprocess.run(["git", "-C", str(repo), *args], text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode != 0:
        raise ScenarioError(f"GIT_FAILED: git {' '.join(args)}: {p.stderr.strip()}")
    return p.stdout.strip()


def require_dict(mapping: dict[str, Any], key: str, er: str) -> dict[str, Any]:
    value = mapping.get(key)
    if not isinstance(value, dict):
        raise ScenarioError(f"DB_ACTIVE_POLICY_PARAMETER_MISSING: er={er} parameter={key}")
    return value


def require_list(mapping: dict[str, Any], key: str, er: str) -> list[Any]:
    value = mapping.get(key)
    if not isinstance(value, list) or len(value) == 0:
        raise ScenarioError(f"DB_ACTIVE_POLICY_PARAMETER_MISSING: er={er} parameter={key}")
    return value


def require_number(mapping: dict[str, Any], key: str, er: str, field: str | None = None) -> float:
    if key not in mapping or not isinstance(mapping.get(key), (int,float)) or isinstance(mapping.get(key), bool):
        label = field or key
        raise ScenarioError(f"DB_ACTIVE_POLICY_PARAMETER_MISSING: er={er} field={label}")
    return float(mapping[key])


def require_bool(mapping: dict[str, Any], key: str, er: str, field: str | None = None) -> bool:
    if key not in mapping or not isinstance(mapping.get(key), bool):
        label = field or key
        raise ScenarioError(f"DB_ACTIVE_POLICY_PARAMETER_MISSING: er={er} field={label}")
    return bool(mapping[key])


def resolve_value(value: Any, effective: dict[str, Any]) -> Any:
    if isinstance(value, dict) and value.get("kind") == "threshold_ref":
        pid = str(value.get("parameter_id") or "")
        if pid not in effective:
            raise ScenarioError(f"DB_THRESHOLD_REF_UNRESOLVED: parameter={pid}")
        return effective[pid]
    return value


def eval_ast(ast: dict[str, Any], facts: dict[str, Any], effective: dict[str, Any]) -> bool:
    kind = str(ast.get("kind") or "")
    if kind in {"all","and"}:
        return all(eval_ast(x, facts, effective) for x in ast.get("nodes", ast.get("conditions", [])) if isinstance(x, dict))
    if kind in {"any","or"}:
        return any(eval_ast(x, facts, effective) for x in ast.get("nodes", ast.get("conditions", [])) if isinstance(x, dict))
    if kind == "not":
        child = ast.get("node") or ast.get("condition") or {}
        return not eval_ast(child, facts, effective) if isinstance(child, dict) else False
    if kind not in {"predicate","comparison"}:
        return False
    fact = ast.get("factId") or ast.get("fact_id")
    left = facts.get(str(fact))
    right = resolve_value(ast.get("value"), effective)
    op = str(ast.get("operator") or "")
    try:
        if op == "eq": return left == right
        if op in {"neq","ne"}: return left != right
        if op == "gt": return left > right
        if op == "gte": return left >= right
        if op == "lt": return left < right
        if op == "lte": return left <= right
        if op == "in": return left in right
        if op in {"not_in","nin"}: return left not in right
        if op == "matches_regex": return bool(re.search(str(right), str(left or "")))
        if op == "not_matches_regex": return not bool(re.search(str(right), str(left or "")))
    except Exception:
        return False
    return False


def evaluate_policy(policy: dict[str, Any], facts: dict[str, Any]) -> str | None:
    effective = policy["effectiveParameterValues"]
    rules = policy.get("governedRules")
    if not isinstance(rules, list):
        raise ScenarioError(
            f"DB_GOVERNED_RULES_MISSING: er={policy.get('erId')}"
        )

    def db_priority(rule: dict[str, Any]) -> int:
        if "priority" not in rule:
            raise ScenarioError(
                f"DB_RULE_PRIORITY_MISSING: er={policy.get('erId')} rule={rule.get('rule_id')}"
            )
        try:
            return int(rule["priority"])
        except Exception as exc:
            raise ScenarioError(
                f"DB_RULE_PRIORITY_INVALID: er={policy.get('erId')} "
                f"rule={rule.get('rule_id')} priority={rule.get('priority')}"
            ) from exc

    for rule in sorted(rules, key=db_priority):
        ast = rule.get("ast")
        if isinstance(ast, dict) and eval_ast(ast, facts, effective):
            return str(rule.get("outcome") or "")
    return policy.get("noMatchOutcome")


def find_predicate(ast: dict[str, Any], *, fact: str, operators: set[str]) -> dict[str, Any] | None:
    kind = str(ast.get("kind") or "")
    if kind in {"predicate","comparison"}:
        if str(ast.get("factId") or ast.get("fact_id") or "") == fact and str(ast.get("operator") or "") in operators:
            return ast
        return None
    for child in ast.get("nodes", ast.get("conditions", [])) or []:
        if isinstance(child, dict):
            got = find_predicate(child, fact=fact, operators=operators)
            if got: return got
    child = ast.get("node") or ast.get("condition")
    if isinstance(child, dict):
        return find_predicate(child, fact=fact, operators=operators)
    return None


def rule_threshold(policy: dict[str, Any], outcome: str, fact: str, operators: set[str]) -> tuple[str, float]:
    effective = policy["effectiveParameterValues"]
    for rule in sorted(policy.get("governedRules", []), key=lambda r: int(r["priority"])):
        if str(rule.get("outcome")) != outcome:
            continue
        ast = rule.get("ast")
        if not isinstance(ast, dict):
            continue
        pred = find_predicate(ast, fact=fact, operators=operators)
        if pred:
            raw = resolve_value(pred.get("value"), effective)
            if not isinstance(raw, (int,float)) or isinstance(raw, bool):
                raise ScenarioError(f"DB_THRESHOLD_NOT_NUMERIC: er={policy['erId']} fact={fact}")
            return str(pred.get("operator")), float(raw)
    raise ScenarioError(f"DB_THRESHOLD_RULE_MISSING: er={policy['erId']} outcome={outcome} fact={fact}")


def threshold_crossing(operator: str, value: float) -> int:
    if int(value) != value:
        if operator in {"gt","gte"}:
            return int(value) + 1
    n = int(value)
    if operator == "gt": return n + 1
    if operator == "gte": return n
    raise ScenarioError(f"UNSUPPORTED_THRESHOLD_OPERATOR: {operator}")


def write_text(repo: Path, rel: str, content: str) -> Path:
    p = (repo / rel).resolve()
    try:
        p.relative_to(repo.resolve())
    except ValueError:
        raise ScenarioError(f"PATH_OUTSIDE_REPO: {rel}")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


def regex_witness(pattern: str) -> str:
    # Dynamic witness generation. No policy-specific prefix or numeric threshold is embedded.
    try:
        import sre_parse
        parsed = sre_parse.parse(pattern)
        def emit(tokens) -> str:
            out = []
            for op, arg in tokens:
                name = str(op)
                if name == "LITERAL":
                    out.append(chr(arg))
                elif name == "SUBPATTERN":
                    out.append(emit(arg[-1]))
                elif name == "BRANCH":
                    branches = arg[1]
                    out.append(emit(branches[0]) if branches else "")
                elif name in {"MAX_REPEAT","MIN_REPEAT","POSSESSIVE_REPEAT"}:
                    mn, mx, sub = arg
                    count = mn
                    if count == 0 and mx != 0:
                        count = 1
                    out.append(emit(sub) * count)
                elif name == "IN":
                    chosen = "a"
                    for iop, iarg in arg:
                        iname = str(iop)
                        if iname == "LITERAL":
                            chosen = chr(iarg); break
                        if iname == "RANGE":
                            chosen = chr(iarg[0]); break
                        if iname == "CATEGORY":
                            cat = str(iarg)
                            chosen = "0" if "DIGIT" in cat else ("a" if "WORD" in cat else " ")
                            break
                    out.append(chosen)
                elif name == "CATEGORY":
                    cat = str(arg)
                    out.append("0" if "DIGIT" in cat else ("a" if "WORD" in cat else " "))
                elif name == "ANY":
                    out.append("a")
                elif name == "AT":
                    pass
                else:
                    raise ValueError(name)
            return "".join(out)
        candidate = emit(parsed)
        if re.search(pattern, candidate):
            return candidate
    except Exception:
        pass
    candidates = [
        "feature/zeroui-demo", "chore/zeroui-demo", "test/zeroui-demo",
        "zeroui_demo.sql", "001_zeroui_demo.sql", "zeroui_demo",
        "api_key", "password", "secret_key", "token",
    ]
    for candidate in candidates:
        try:
            if re.search(pattern, candidate):
                return candidate
        except re.error as exc:
            raise ScenarioError(f"DB_POLICY_REGEX_INVALID: {pattern}: {exc}")
    raise ScenarioError(f"REGEX_WITNESS_UNRESOLVED: {pattern}")


def dynamic_compliant_branch(token: str) -> str:
    p = load_active_policy("ER-074")
    print_provenance(p)
    patterns = [str(x) for x in require_list(p["effectiveParameterValues"], "allowed_patterns", "ER-074")]
    token_candidates = [
        f"feature/zeroui-demo-{token}",
        f"chore/zeroui-demo-{token}",
        f"test/zeroui-demo-{token}",
        f"build/zeroui-demo-{token}",
        f"zeroui-demo-{token}",
    ]
    for candidate in token_candidates:
        for pattern in patterns:
            try:
                if re.fullmatch(pattern, candidate) or re.search(pattern, candidate):
                    return candidate
            except re.error as exc:
                raise ScenarioError(f"DB_POLICY_REGEX_INVALID: {pattern}: {exc}")
    for pattern in patterns:
        witness = regex_witness(pattern)
        try:
            if re.fullmatch(pattern, witness) or re.search(pattern, witness):
                return witness
        except re.error:
            continue
    raise ScenarioError("ER074_COMPLIANT_BRANCH_UNRESOLVED_FROM_DB")

def dynamic_noncompliant_branch(token: str) -> str:
    p = load_active_policy("ER-074")
    print_provenance(p)
    patterns = [str(x) for x in require_list(p["effectiveParameterValues"], "allowed_patterns", "ER-074")]
    for candidate in [f"zeroui-demo-{token}", f"invalid_{token}", f"root-{token}"]:
        if not any(re.search(pattern, candidate) for pattern in patterns):
            return candidate
    raise ScenarioError("ER074_NONCOMPLIANT_BRANCH_UNRESOLVED_FROM_DB")


def er007_policy(policy: dict[str, Any]) -> dict[str, Any]:
    return require_dict(policy["effectiveParameterValues"], "er007_policy", "ER-007")


def choose_er007_path(cfg: dict[str, Any], token: str) -> str:
    scans = cfg.get("scan_folders")
    if not isinstance(scans, list) or not scans:
        raise ScenarioError("DB_ACTIVE_POLICY_PARAMETER_MISSING: er=ER-007 field=er007_policy.scan_folders")
    for raw in scans:
        pat = str(raw).replace("\\","/")
        if ".sql" not in pat.lower() and "*" in pat:
            continue
        if "*" not in pat and "?" not in pat and "[" not in pat:
            base = pat.rstrip("/")
            return f"{base}/zeroui_er007_demo_{token}.sql" if base else f"zeroui_er007_demo_{token}.sql"
        prefix = re.split(r"[*?\[]", pat, maxsplit=1)[0].rstrip("/")
        return f"{prefix + '/' if prefix else ''}zeroui_er007_demo_{token}.sql"
    raise ScenarioError("ER007_SQL_SCAN_PATH_UNRESOLVED_FROM_DB")


def risky_sql_text(cfg: dict[str, Any]) -> str:
    risky = cfg.get("risky_sql")
    if not isinstance(risky, list) or not risky:
        raise ScenarioError("DB_ACTIVE_POLICY_PARAMETER_MISSING: er=ER-007 field=er007_policy.risky_sql")
    for row in risky:
        if not isinstance(row, dict):
            continue
        if isinstance(row.get("test"), str) and row["test"].strip():
            return row["test"].strip() + "\n"
        if isinstance(row.get("find"), str) and row["find"].strip():
            return row["find"].strip() + " zeroui_demo;\n"
        if isinstance(row.get("find_regex"), str) and row["find_regex"].strip():
            return regex_witness(row["find_regex"]) + "\n"
    raise ScenarioError("ER007_RISKY_SQL_FIXTURE_UNRESOLVED_FROM_DB")


def all_er007_proofs(cfg: dict[str, Any]) -> list[str]:
    proofs = cfg.get("proof_lines")
    if not isinstance(proofs, list) or not proofs:
        raise ScenarioError("DB_ACTIVE_POLICY_PARAMETER_MISSING: er=ER-007 field=er007_policy.proof_lines")
    result=[]
    for row in proofs:
        if not isinstance(row, dict): continue
        paste = row.get("paste")
        key = row.get("key")
        if isinstance(paste, str) and paste.strip():
            result.append(paste.strip())
        elif isinstance(key, str) and key.strip():
            result.append(f"-- {key.strip()}: zeroui controlled proof")
    if not result:
        raise ScenarioError("ER007_PROOF_FIXTURE_UNRESOLVED_FROM_DB")
    return result


def er072_rule_fixture(policy: dict[str, Any], confidence: str, token: str, count: int) -> str:
    effective = policy["effectiveParameterValues"]
    rules = require_list(effective, "detection_rules", "ER-072")
    erp = require_dict(effective, "er072_policy", "ER-072")
    med_len = int(require_number(erp, "medium_confidence_min_length", "ER-072", "er072_policy.medium_confidence_min_length"))
    med_run = int(require_number(erp, "medium_confidence_min_alnum_run", "ER-072", "er072_policy.medium_confidence_min_alnum_run"))
    candidates = [r for r in rules if isinstance(r, dict) and str(r.get("confidence","")).lower() == confidence]
    if not candidates:
        raise ScenarioError(f"SCENARIO_UNSUPPORTED_BY_ACTIVE_POLICY: ER-072 no {confidence} detection rule")
    rule = candidates[0]
    lines=[]
    for i in range(count):
        rtype = str(rule.get("type") or "")
        if rtype == "sensitive_key_value":
            kp = str(rule.get("key_pattern") or "")
            if not kp:
                raise ScenarioError("ER072_KEY_PATTERN_MISSING_IN_DB_RULE")
            key = regex_witness(kp)
            min_len = int(rule.get("min_length") or 1)
            needed = max(1, min_len, med_len if confidence == "medium" else 1, med_run if confidence == "medium" else 1)
            value = ("Ab9" * ((needed + 2)//3))[:needed]
            value = value[:-1] + chr(ord("a") + (i % 20)) if len(value) > 1 else "Q"
            lines.append(f'{key}="{value}"')
        elif rtype == "regex":
            pat = str(rule.get("pattern") or "")
            if not pat:
                raise ScenarioError("ER072_REGEX_PATTERN_MISSING_IN_DB_RULE")
            lines.append(regex_witness(pat))
        else:
            raise ScenarioError(f"ER072_RULE_TYPE_UNSUPPORTED_FOR_DEMO: {rtype}")
    return "\n".join(lines) + "\n"


ER073_DEMO_SOURCE_RELATIVE_PATH = "test_zeroui_er073_demo.py"
ER073_DEMO_MARKER = "# ZEROUI_ER073_DEMO_OWNED"


def er073_semantic_rules(policy: dict[str, Any]) -> list[dict[str, Any]]:
    raw = policy["effectiveParameterValues"].get("semantic_detection_rules")
    if not isinstance(raw, list) or not raw:
        raise ScenarioError(
            "DB_ACTIVE_POLICY_PARAMETER_MISSING: er=ER-073 field=semantic_detection_rules"
        )
    rows = [x for x in raw if isinstance(x, dict)]
    if not rows:
        raise ScenarioError("ER073_DB_SEMANTIC_DETECTION_RULES_INVALID")
    return rows


def require_er073_demo_construct_enabled(policy: dict[str, Any]) -> dict[str, Any]:
    wanted = ("python", "pytest", "pytest.mark.skip")
    for row in er073_semantic_rules(policy):
        key = (
            str(row.get("language") or "").strip().lower(),
            str(row.get("framework") or "").strip().lower(),
            str(row.get("construct") or "").strip(),
        )
        if key == wanted and row.get("enabled") is True:
            return row
    raise ScenarioError(
        "ER073_DB_DEMO_CONSTRUCT_NOT_ENABLED: active semantic_detection_rules does not enable "
        "python|pytest|pytest.mark.skip"
    )


def er073_demo_path(repo: Path) -> Path:
    p = (repo / ER073_DEMO_SOURCE_RELATIVE_PATH).resolve()
    try:
        p.relative_to(repo.resolve())
    except ValueError as exc:
        raise ScenarioError("ER073_DEMO_PATH_OUTSIDE_REPO") from exc
    return p


def er073_demo_owned(repo: Path) -> bool:
    p = er073_demo_path(repo)
    if not p.is_file():
        return False
    try:
        return ER073_DEMO_MARKER in p.read_text(encoding="utf-8")
    except Exception:
        return False


def ensure_er073_demo_path_safe(repo: Path) -> None:
    p = er073_demo_path(repo)
    if p.exists() and not er073_demo_owned(repo):
        raise ScenarioError(
            f"ER073_DEMO_FIXTURE_COLLISION: refusing to overwrite non-demo file "
            f"{ER073_DEMO_SOURCE_RELATIVE_PATH}"
        )


def write_er073_source_fixture(repo: Path, *, blocked: bool) -> None:
    ensure_er073_demo_path_safe(repo)
    p = er073_demo_path(repo)
    if blocked:
        body = (
            ER073_DEMO_MARKER + "\n"
            "import pytest\n\n"
            "@pytest.mark.skip(reason=\"ZeroUI ER-073 governed demo skip\")\n"
            "def test_zeroui_er073_demo_skip():\n"
            "    assert True\n"
        )
    else:
        body = (
            ER073_DEMO_MARKER + "\n"
            "import pytest\n\n"
            "def test_zeroui_er073_demo_pass():\n"
            "    assert True\n"
        )
    p.write_text(body, encoding="utf-8")


def junit_xml(status: str, token: str, count: int = 1, explicit_message: bool = True) -> str:
    cases=[]
    for i in range(max(1,count)):
        name=f"test_zeroui_{token}_{i}"
        if status == "passed":
            body=f'<testcase classname="zeroui.demo" name="{name}"/>'
        elif status == "failed":
            body=f'<testcase classname="zeroui.demo" name="{name}"><failure message="controlled failure"/></testcase>'
        elif status == "skipped":
            msg=' message="controlled skip"' if explicit_message else ""
            body=f'<testcase classname="zeroui.demo" name="{name}"><skipped{msg}/></testcase>'
        else:
            raise ScenarioError(f"ER073_JUNIT_STATUS_UNSUPPORTED: {status}")
        cases.append(body)
    skipped = count if status=="skipped" else 0
    failures = count if status=="failed" else 0
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<testsuites tests="{count}" skipped="{skipped}" failures="{failures}" errors="0">'
        f'<testsuite name="zeroui-demo" tests="{count}" skipped="{skipped}" failures="{failures}" errors="0">'
        + "".join(cases) + "</testsuite></testsuites>\n"
    )


def er075_profiles(policy: dict[str, Any]) -> list[dict[str,Any]]:
    effective = policy["effectiveParameterValues"]
    for key in ("profiles","test_profiles"):
        value = effective.get(key)
        if isinstance(value, list) and value:
            return [x for x in value if isinstance(x, dict)]
    for key, value in effective.items():
        if isinstance(value, dict):
            for nested in ("profiles","test_profiles"):
                rows = value.get(nested)
                if isinstance(rows, list) and rows:
                    return [x for x in rows if isinstance(x, dict)]
    raise ScenarioError(
        "DB_ACTIVE_POLICY_TEST_PROFILES_MISSING: ER-075 active relational policy does not expose "
        "profiles/test_profiles; no hardcoded artifact path fallback is permitted."
    )


def write_er075_artifacts(repo: Path, policy: dict[str, Any], status: str, token: str) -> None:
    profiles = er075_profiles(policy)
    wrote=0
    for p in profiles:
        ev = p.get("evidence")
        if not isinstance(ev, dict) or ev.get("source") != "artifact" or not ev.get("configuredLocation"):
            raise ScenarioError(
                f"ER075_PROFILE_UNSUPPORTED_FOR_DETERMINISTIC_DEMO: profile={p.get('id')} "
                "must use DB-configured artifact evidence."
            )
        framework = str(p.get("framework") or "").lower()
        if framework not in {"pytest","jest"}:
            raise ScenarioError(f"ER075_FRAMEWORK_UNSUPPORTED: {framework}")
        write_text(repo, str(ev["configuredLocation"]), junit_xml(status, token, 1, True))
        wrote += 1
    if not wrote:
        raise ScenarioError("ER075_NO_DB_CONFIGURED_ARTIFACT_PROFILE")


def er076_config(policy: dict[str, Any]) -> dict[str, Any]:
    e = policy["effectiveParameterValues"]
    if isinstance(e.get("er076_policy"), dict):
        return dict(e["er076_policy"])
    keys=("scan_folders","allowed_name_patterns","exclude_path_segments")
    if all(k in e for k in keys):
        return {k:e[k] for k in keys}
    raise ScenarioError(
        "DB_ACTIVE_POLICY_PARAMETER_MISSING: ER-076 requires DB effective scan_folders, "
        "allowed_name_patterns and exclude_path_segments (directly or under er076_policy)."
    )


def er076_scan_paths(repo: Path, cfg: dict[str,Any]) -> list[Path]:
    scans = cfg.get("scan_folders")
    if not isinstance(scans,list) or not scans:
        raise ScenarioError("ER076_DB_SCAN_FOLDERS_MISSING")
    files=[]
    for p in repo.rglob("*.sql"):
        rel=p.relative_to(repo).as_posix()
        for raw in scans:
            s=str(raw).replace("\\","/").rstrip("/")
            if any(ch in s for ch in "*?["):
                if fnmatch.fnmatch(rel,s) or Path(rel).match(s):
                    files.append(p);break
            elif rel==s or rel.startswith(s+"/"):
                files.append(p);break
    return sorted(set(files))


def er076_excluded(rel: str, cfg: dict[str,Any]) -> bool:
    segs = cfg.get("exclude_path_segments")
    if not isinstance(segs,list):
        raise ScenarioError("ER076_DB_EXCLUDE_SEGMENTS_MISSING")
    parts=rel.replace("\\","/").split("/")
    return any(any(part.lower()==str(seg).lower() for part in parts) for seg in segs)


def er076_valid_filename(cfg: dict[str,Any]) -> str:
    pats=cfg.get("allowed_name_patterns")
    if not isinstance(pats,list) or not pats:
        raise ScenarioError("ER076_DB_ALLOWED_NAME_PATTERNS_MISSING")
    for raw in pats:
        pattern=str(raw)
        candidate=regex_witness(pattern)
        if re.search(pattern,candidate):
            return candidate
    raise ScenarioError("ER076_VALID_FILENAME_UNRESOLVED_FROM_DB")


def er076_demo_path(cfg: dict[str,Any], filename: str) -> str:
    scans=cfg.get("scan_folders")
    if not isinstance(scans,list) or not scans:
        raise ScenarioError("ER076_DB_SCAN_FOLDERS_MISSING")
    for raw in scans:
        s=str(raw).replace("\\","/")
        if any(ch in s for ch in "*?["):
            prefix=re.split(r"[*?\[]",s,maxsplit=1)[0].rstrip("/")
            return f"{prefix + '/' if prefix else ''}{filename}"
        return f"{s.rstrip('/')}/{filename}"
    raise ScenarioError("ER076_DEMO_PATH_UNRESOLVED")


def severity(raw: str) -> str:
    x=str(raw or "").strip().lower()
    if x in {"none","low","medium","high","critical"}: return x
    if "critical" in x: return "critical"
    if "high" in x: return "high"
    if "moderate" in x or "medium" in x: return "medium"
    if "low" in x: return "low"
    return "unknown"


def osv_severity(v: dict[str,Any]) -> str:
    ds=v.get("database_specific")
    if isinstance(ds,dict) and ds.get("severity"):
        return severity(ds["severity"])
    # Mirror current scanner behavior: only a numeric-leading CVSS score can map.
    for e in v.get("severity") or []:
        if isinstance(e,dict) and e.get("type")=="CVSS_V3":
            raw=str(e.get("score") or "")
            try:
                score=float(raw.split("/")[0])
            except Exception:
                continue
            if score>=9: return "critical"
            if score>=7: return "high"
            if score>=4: return "medium"
            if score>0: return "low"
    return "unknown"


def osv_query_package(name: str) -> dict[str,Any]:
    payload=json.dumps({"package":{"name":name,"ecosystem":"npm"}}).encode()
    req=urllib.request.Request("https://api.osv.dev/v1/query",data=payload,
                               headers={"Content-Type":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=8) as resp:
            return json.loads(resp.read().decode())
    except Exception as exc:
        raise ScenarioError(f"ER077_OSV_DISCOVERY_FAILED: {exc}")


def er077_threshold(policy: dict[str,Any]) -> tuple[dict[str,Any],list[str],str]:
    e=policy["effectiveParameterValues"]
    cfg=require_dict(e,"er077_policy","ER-077")
    order=[str(x).lower() for x in cfg.get("severity_order",[])]
    threshold=str(cfg.get("block_at_or_above") or "").lower()
    if not order or threshold not in order:
        raise ScenarioError("ER077_DB_SEVERITY_THRESHOLD_INVALID")
    return cfg,order,threshold


def discover_vulnerable_fixture(policy: dict[str,Any], *, exact_threshold: bool) -> tuple[str,str,str]:
    cfg,order,threshold=er077_threshold(policy)
    ti=order.index(threshold)
    repo_candidates=[]
    # Existing package names first.
    package_json=Path(os.environ.get("ZEROUI_DEMO_REPO",""))/"package.json"
    if package_json.is_file():
        try:
            obj=json.loads(package_json.read_text())
            for section in ("dependencies","devDependencies"):
                if isinstance(obj.get(section),dict):
                    repo_candidates += list(obj[section].keys())
        except Exception:
            pass
    candidates=repo_candidates+["lodash","minimist","axios","semver","tar","glob","ws"]
    seen=set()
    for name in candidates:
        if name in seen: continue
        seen.add(name)
        data=osv_query_package(name)
        for vuln in data.get("vulns") or []:
            if not isinstance(vuln,dict) or vuln.get("withdrawn"): continue
            sev=osv_severity(vuln)
            if sev not in order or sev=="unknown": continue
            if exact_threshold and sev != threshold: continue
            if not exact_threshold and order.index(sev) < ti: continue
            for affected in vuln.get("affected") or []:
                if not isinstance(affected,dict): continue
                pkg=affected.get("package") or {}
                if pkg.get("name")!=name or str(pkg.get("ecosystem","")).lower()!="npm": continue
                versions=affected.get("versions")
                if isinstance(versions,list) and versions:
                    return name,str(versions[0]),sev
    kind="exact-threshold" if exact_threshold else "threshold-breaching"
    raise ScenarioError(f"ER077_OSV_FIXTURE_UNRESOLVED: no live {kind} npm finding discovered")


def write_npm_fixture(repo: Path, name: str, version: str, direct: bool) -> None:
    package={"name":"zeroui-er077-demo","version":"1.0.0"}
    root={"name":"zeroui-er077-demo","version":"1.0.0"}
    if direct:
        package["dependencies"]={name:version}
        root["dependencies"]={name:version}
    lock={
        "name":"zeroui-er077-demo","version":"1.0.0","lockfileVersion":3,
        "requires":True,
        "packages":{
            "":root,
            f"node_modules/{name}":{"version":version}
        }
    }
    write_text(repo,"package.json",json.dumps(package,indent=2)+"\n")
    write_text(repo,"package-lock.json",json.dumps(lock,indent=2)+"\n")


def er077_directness(policy: dict[str,Any]) -> bool:
    cfg,_,_=er077_threshold(policy)
    if cfg.get("include_direct_dependencies") is True:
        return True
    if cfg.get("include_transitive_dependencies") is True:
        return False
    raise ScenarioError("ER077_ACTIVE_POLICY_EXCLUDES_BOTH_DIRECT_AND_TRANSITIVE")


def safe_er077_fixture(repo: Path, policy: dict[str,Any], token: str) -> None:
    direct=er077_directness(policy)
    name=f"zeroui-demo-no-vuln-{token}"
    write_npm_fixture(repo,name,"0.0.1",direct)


def prepare_baseline(repo: Path, er: str, policy: dict[str,Any], token: str) -> None:
    if er == "ER-073":
        rule = require_er073_demo_construct_enabled(policy)
        ensure_er073_demo_path_safe(repo)
        print("ER073_TRIGGER_AUTHORITY=workspace_source_scan")
        print("ER073_JUNIT_TRIGGER_AUTHORITY=NO")
        print(
            "ER073_DB_ENABLED_SEMANTIC_RULE="
            + "|".join([
                str(rule.get("language") or ""),
                str(rule.get("framework") or ""),
                str(rule.get("construct") or ""),
            ])
        )
    if er == "ER-076":
        cfg=er076_config(policy)
        patterns=[re.compile(str(x)) for x in cfg.get("allowed_name_patterns",[])]
        bad=[]
        for p in er076_scan_paths(repo,cfg):
            rel=p.relative_to(repo).as_posix()
            if er076_excluded(rel,cfg):
                continue
            if not any(r.search(p.name) for r in patterns):
                bad.append(rel)
        if bad:
            raise ScenarioError(
                "ER076_BASELINE_ALREADY_VIOLATES_ACTIVE_DB_POLICY: " + ",".join(bad[:20])
            )

def apply(repo: Path, er: str, scenario: str, token: str) -> str:
    policy=load_active_policy(er)
    print_provenance(policy)
    e=policy["effectiveParameterValues"]

    if er=="ER-001":
        if scenario=="CLEAN-ALLOW":
            facts={"files_changed":0,"lines_changed":0,"services_modules_touched":0}
            outcome=evaluate_policy(policy,facts)
            if outcome!="allow":
                raise ScenarioError(f"ACTIVE_DB_POLICY_DOES_NOT_ALLOW_CLEAN_SCOPE: outcome={outcome}")
            return "clean change scope"
        if scenario=="FILE-COUNT-DENY":
            op,th=rule_threshold(policy,"deny","files_changed",{"gt","gte"})
            count=threshold_crossing(op,th)
            if count<1 or count>10000:
                raise ScenarioError(f"ER001_DYNAMIC_FILE_COUNT_OUTSIDE_DEMO_SAFETY_CAP: {count}")
            d=repo/f"zeroui-er001-files-{token}"; d.mkdir()
            for i in range(count):
                (d/f"f{i}.txt").write_text("x\n")
            return f"DB-derived file-count breach: observed={count} threshold={th} operator={op}"
        if scenario=="LINE-COUNT-REVIEW":
            op,th=rule_threshold(policy,"human_review_required","lines_changed",{"gt","gte"})
            count=threshold_crossing(op,th)
            # Ensure the selected review boundary does not cross a DB deny line threshold.
            try:
                dop,dth=rule_threshold(policy,"deny","lines_changed",{"gt","gte"})
                deny_cross=threshold_crossing(dop,dth)
                if count>=deny_cross:
                    raise ScenarioError("ER001_NO_REVIEW_GAP_IN_ACTIVE_DB_POLICY")
            except ScenarioError as exc:
                if str(exc).startswith("DB_THRESHOLD_RULE_MISSING"):
                    pass
                else:
                    raise
            if count<1 or count>200000:
                raise ScenarioError(f"ER001_DYNAMIC_LINE_COUNT_OUTSIDE_DEMO_SAFETY_CAP: {count}")
            write_text(repo,f"zeroui-er001-lines-{token}.txt","".join(f"line-{i}\n" for i in range(count)))
            return f"DB-derived line-count review crossing: observed={count} threshold={th} operator={op}"

    if er=="ER-007":
        cfg=er007_policy(policy)
        rel=choose_er007_path(cfg,token)
        if scenario=="SAFE-SQL-ALLOW":
            candidates=["SELECT 1;\n","CREATE TABLE zeroui_demo_safe (id INTEGER);\n"]
            risky=cfg.get("risky_sql") or []
            chosen=None
            for c in candidates:
                hit=False
                for r in risky:
                    if not isinstance(r,dict): continue
                    if r.get("find") and str(r["find"]).lower() in c.lower(): hit=True
                    if r.get("find_regex") and re.search(str(r["find_regex"]),c,re.I): hit=True
                if not hit: chosen=c;break
            if chosen is None: raise ScenarioError("ER007_SAFE_SQL_UNRESOLVED_FROM_DB_POLICY")
            write_text(repo,rel,chosen); return f"safe SQL under DB scan scope: {rel}"
        risky=risky_sql_text(cfg)
        if scenario=="RISKY-SQL-DENY":
            write_text(repo,rel,risky); return f"DB-derived risky SQL without proof: {rel}"
        if scenario=="RISKY-SQL-CONTROLS-REVIEW":
            proofs="\n".join(all_er007_proofs(cfg))+"\n"
            write_text(repo,rel,proofs+risky); return f"DB-derived risky SQL with DB proof lines: {rel}"

    if er=="ER-072":
        erp=require_dict(e,"er072_policy","ER-072")
        if scenario=="NO-SECRET-ALLOW":
            write_text(repo,f"zeroui-er072-{token}.txt","zeroui_demo_flag=true\n")
            return "non-secret controlled content"
        if scenario=="HIGH-CONFIDENCE-DENY":
            deny_conf = erp.get("minimum_confidence_for_deny")
            if not isinstance(deny_conf, str) or not deny_conf.strip():
                raise ScenarioError("DB_ACTIVE_POLICY_PARAMETER_MISSING: er=ER-072 field=er072_policy.minimum_confidence_for_deny")
            deny_conf = deny_conf.strip().lower()
            # Current ER-072 semantic detector has explicit high-block / medium-warning states.
            if deny_conf != "high":
                raise ScenarioError(
                    f"SCENARIO_UNSUPPORTED_BY_ACTIVE_POLICY: ER-072 current evaluator cannot guarantee DENY for minimum_confidence_for_deny={deny_conf}"
                )
            count_key = "minimum_high_confidence_for_block" if "minimum_high_confidence_for_block" in erp else "min_detection_rules"
            count = int(require_number(erp, count_key, "ER-072", f"er072_policy.{count_key}"))
            if count <= 0:
                raise ScenarioError("ER072_DB_BLOCK_COUNT_INVALID")
            write_text(repo,f"zeroui-er072-{token}.env",er072_rule_fixture(policy,deny_conf,token,count))
            return f"DB-derived blocking-confidence findings confidence={deny_conf} count={count}"
        if scenario=="DB-DERIVED-WARN":
            deny_conf_raw = erp.get("minimum_confidence_for_deny")
            if not isinstance(deny_conf_raw, str) or not deny_conf_raw.strip():
                raise ScenarioError(
                    "DB_ACTIVE_POLICY_PARAMETER_MISSING: "
                    "er=ER-072 field=er072_policy.minimum_confidence_for_deny"
                )
            deny_conf = deny_conf_raw.strip().lower()
            rules = require_list(e, "detection_rules", "ER-072")
            available = []
            for row in rules:
                if not isinstance(row, dict):
                    continue
                confidence = str(row.get("confidence") or "").strip().lower()
                if confidence and confidence != deny_conf and confidence not in available:
                    available.append(confidence)

            # Production ER-072's warning semantic is the DB-provided medium-confidence
            # rule lane. "medium" here is an evaluator semantic state, not a threshold
            # value. Its value-length/alnum thresholds come only from PostgreSQL.
            warning_confidence = next(
                (value for value in available if value == "medium"),
                None,
            )
            if warning_confidence is None:
                raise ScenarioError(
                    "ER072_ACTIVE_DB_POLICY_HAS_NO_SUPPORTED_WARNING_CONFIDENCE: "
                    f"deny_confidence={deny_conf} available={available}"
                )

            write_text(
                repo,
                f"zeroui-er072-{token}.env",
                er072_rule_fixture(policy, warning_confidence, token, 1),
            )
            return (
                "DB-derived warning-confidence finding "
                f"confidence={warning_confidence} deny_confidence={deny_conf}"
            )

    if er=="ER-073":
        rule = require_er073_demo_construct_enabled(policy)
        if scenario=="PASSED-ALLOW":
            write_er073_source_fixture(repo, blocked=False)
            source_eval="NOT_DETECTED"
        elif scenario=="BLOCKED-STATUS-DENY":
            write_er073_source_fixture(repo, blocked=True)
            source_eval="DETECTED"
        elif scenario=="IGNORED-STATUS-ALLOW":
            write_er073_source_fixture(repo, blocked=False)
            source_eval="NOT_DETECTED"
        else:
            raise ScenarioError(f"UNKNOWN_SCENARIO: {scenario}")
        return (
            f"ER073_TRIGGER_AUTHORITY=workspace_source_scan "
            f"DB_RULE={rule.get('language')}|{rule.get('framework')}|{rule.get('construct')} "
            f"fixture={ER073_DEMO_SOURCE_RELATIVE_PATH} expected_source_evaluation={source_eval}"
        )

    if er=="ER-074":
        # Branch is created by lifecycle from the same DB policy.
        return f"branch scenario active: {git(repo,'branch','--show-current',check=False) or 'DETACHED'}"

    if er=="ER-075":
        if scenario=="PASSING-TEST-ALLOW": status="passed"
        elif scenario=="FAILING-TEST-DENY": status="failed"
        elif scenario=="SKIPPED-NOT-FAILED-CORNER": status="skipped"
        else: raise ScenarioError(f"UNKNOWN_SCENARIO: {scenario}")
        write_er075_artifacts(repo,policy,status,token)
        return f"DB-configured ER-075 artifact profiles written status={status}"

    if er=="ER-076":
        cfg=er076_config(policy)
        if scenario=="COMPLIANT-MIGRATION-ALLOW":
            name=er076_valid_filename(cfg)
            write_text(repo,er076_demo_path(cfg,name),"SELECT 1;\n")
            return f"DB-compliant migration filename={name}"
        if scenario=="BAD-FILENAME-DENY":
            pats=[re.compile(str(x)) for x in cfg.get("allowed_name_patterns",[])]
            for cand in [f"zeroui_bad_{token}.sql",f"BAD-{token}.sql",f"{token}.txt.sql"]:
                if not any(r.search(cand) for r in pats):
                    write_text(repo,er076_demo_path(cfg,cand),"SELECT 1;\n")
                    return f"DB-noncompliant migration filename={cand}"
            raise ScenarioError("ER076_NONCOMPLIANT_FILENAME_UNRESOLVED")
        if scenario=="MODIFIED-TRACKED-DENY":
            for p in er076_scan_paths(repo,cfg):
                rel=p.relative_to(repo).as_posix()
                if er076_excluded(rel,cfg): continue
                if git(repo,"cat-file","-e",f"HEAD:{rel}",check=False)=="":
                    # cat-file success has empty stdout; verify exit via subprocess below
                    q=subprocess.run(["git","-C",str(repo),"cat-file","-e",f"HEAD:{rel}"])
                    if q.returncode==0:
                        with p.open("a",encoding="utf-8") as f: f.write(f"\n-- ZeroUI immutability demo {token}\n")
                        return f"modified DB-scoped tracked migration={rel}"
            raise ScenarioError("ER076_NO_TRACKED_DB_SCOPED_MIGRATION_FOR_CORNER")

    if er=="ER-077":
        cfg,order,threshold=er077_threshold(policy)
        if scenario=="SAFE-DEPENDENCY-ALLOW":
            safe_er077_fixture(repo,policy,token)
            return f"synthetic no-known-vulnerability dependency; DB threshold={threshold}"
        if scenario in {"VULNERABILITY-BREACH-DENY","AT-THRESHOLD-DENY"}:
            exact=scenario=="AT-THRESHOLD-DENY"
            os.environ["ZEROUI_DEMO_REPO"]=str(repo)
            name,version,sev=discover_vulnerable_fixture(policy,exact_threshold=exact)
            direct=er077_directness(policy)
            change_types=[str(x).lower() for x in cfg.get("change_types",[])]
            if change_types and "added" not in change_types and "newly_introduced" not in change_types:
                raise ScenarioError("ER077_ACTIVE_DB_POLICY_DOES_NOT_GOVERN_ADDED_DEPENDENCIES_FOR_FIXTURE")
            write_npm_fixture(repo,name,version,direct)
            return f"live OSV fixture package={name} version={version} severity={sev} DB threshold={threshold}"

    raise ScenarioError(f"UNKNOWN_SCENARIO: er={er} scenario={scenario}")


def recover(repo: Path, er: str, token: str) -> str:
    policy=load_active_policy(er)
    print_provenance(policy)
    if er=="ER-072":
        write_text(repo,f"zeroui-er072-{token}.txt","zeroui_demo_flag=true\n")
        return "safe ER-072 content written for blocker re-evaluation"
    if er=="ER-073":
        rule = require_er073_demo_construct_enabled(policy)
        write_er073_source_fixture(repo, blocked=False)
        return (
            f"ER073_TRIGGER_AUTHORITY=workspace_source_scan "
            f"DB_RULE={rule.get('language')}|{rule.get('framework')}|{rule.get('construct')} "
            f"passing_fixture={ER073_DEMO_SOURCE_RELATIVE_PATH}; "
            "next Check Current Context must reconcile active blocker state from current source"
        )

    if er=="ER-075":
        write_er075_artifacts(repo,policy,"passed","rollback-"+token)
        return "passing DB-configured ER-075 artifacts written"
    if er=="ER-077":
        safe_er077_fixture(repo,policy,"rollback-"+token)
        return "safe changed dependency fixture written under current DB threshold"
    # ER-001/007/074/076 recover through clean working tree + dynamic compliant branch.
    return "clean controlled branch is recovery evidence"


def main() -> int:
    parser=argparse.ArgumentParser()
    sub=parser.add_subparsers(dest="cmd",required=True)
    p=sub.add_parser("branch")
    p.add_argument("--mode",choices=["compliant","noncompliant"],required=True)
    p.add_argument("--token",required=True)
    p=sub.add_parser("prepare")
    p.add_argument("--repo",required=True);p.add_argument("--er",required=True);p.add_argument("--token",required=True)
    p=sub.add_parser("apply")
    p.add_argument("--repo",required=True);p.add_argument("--er",required=True);p.add_argument("--scenario",required=True);p.add_argument("--token",required=True)
    p=sub.add_parser("recover")
    p.add_argument("--repo",required=True);p.add_argument("--er",required=True);p.add_argument("--token",required=True)
    args=parser.parse_args()
    try:
        if args.cmd=="branch":
            name=dynamic_compliant_branch(args.token) if args.mode=="compliant" else dynamic_noncompliant_branch(args.token)
            print(f"BRANCH_NAME={name}")
            return 0
        repo=Path(args.repo).resolve()
        policy=load_active_policy(args.er)
        if args.cmd=="prepare":
            print_provenance(policy)
            prepare_baseline(repo,args.er,policy,args.token)
            print("BASELINE_PREPARED=YES")
            return 0
        if args.cmd=="apply":
            impact=apply(repo,args.er,args.scenario,args.token)
            print(f"SCENARIO_IMPACT={impact}")
            return 0
        if args.cmd=="recover":
            impact=recover(repo,args.er,args.token)
            print(f"RECOVERY_IMPACT={impact}")
            return 0
    except (DemoPolicyError,ScenarioError) as exc:
        print(str(exc),file=sys.stderr)
        return 2
    return 2


if __name__=="__main__":
    raise SystemExit(main())
