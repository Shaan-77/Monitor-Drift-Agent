#!/usr/bin/env python3
from __future__ import annotations
import json, os
from pathlib import Path
from typing import Any
class RuntimeConfigError(RuntimeError): pass
def _strip_jsonc(text:str)->str:
 out=[];i=0;ins=False;esc=False
 while i<len(text):
  ch=text[i];nxt=text[i+1] if i+1<len(text) else ''
  if ins:
   out.append(ch)
   if esc:esc=False
   elif ch=='\\':esc=True
   elif ch=='"':ins=False
   i+=1;continue
  if ch=='"':ins=True;out.append(ch);i+=1;continue
  if ch=='/' and nxt=='/':
   i+=2
   while i<len(text) and text[i] not in '\r\n':i+=1
   continue
  if ch=='/' and nxt=='*':
   i+=2
   while i+1<len(text) and not(text[i]=='*' and text[i+1]=='/'):i+=1
   i+=2;continue
  out.append(ch);i+=1
 cleaned=''.join(out);out2=[];i=0;ins=False;esc=False
 while i<len(cleaned):
  ch=cleaned[i]
  if ins:
   out2.append(ch)
   if esc:esc=False
   elif ch=='\\':esc=True
   elif ch=='"':ins=False
   i+=1;continue
  if ch=='"':ins=True;out2.append(ch);i+=1;continue
  if ch==',':
   j=i+1
   while j<len(cleaned) and cleaned[j].isspace():j+=1
   if j<len(cleaned) and cleaned[j] in '}]':i+=1;continue
  out2.append(ch);i+=1
 return ''.join(out2)
def _read(path:Path)->dict[str,Any]|None:
 try:
  v=json.loads(_strip_jsonc(path.read_text(encoding='utf-8-sig')));return v if isinstance(v,dict) else None
 except Exception:return None
def _settings(repo:Path):
 result=[]
 for p in (repo/'.vscode/settings.json',repo/'.cursor/settings.json',repo/'.zeroui/runtime.json'):
  if p.is_file():
   obj=_read(p)
   if obj is not None:result.append((p,obj))
 return result
def _value(settings,keys):
 for p,obj in settings:
  for k in keys:
   v=obj.get(k)
   if isinstance(v,str) and v.strip():return v.strip(),f'repo_config:{p.name}:{k}'
 return None
def resolve_runtime(repo_root:Path)->dict[str,Any]:
 repo=repo_root.resolve();settings=_settings(repo)
 db=(os.environ.get('ZEROUI_TENANT_DB_URL') or '').strip()
 if db:db_source='process_env:ZEROUI_TENANT_DB_URL'
 else:
  found=_value(settings,('zeroui.ide.tenantDbUrl','tenant_db_url','ZEROUI_TENANT_DB_URL'))
  if not found:raise RuntimeConfigError('TENANT_DB_CONFIG_UNRESOLVED: repo-only mode will not read or modify ZeroUI Extension/VSIX files. Provide ZEROUI_TENANT_DB_URL or configure zeroui.ide.tenantDbUrl in this target repository .vscode/settings.json (or tenant_db_url in .zeroui/runtime.json).')
  db,db_source=found
 tid=(os.environ.get('ZEROUI_TENANT_ID') or os.environ.get('ZEROUI_DEMO_TENANT_ID') or '').strip()
 if tid:tid_source='process_env:ZEROUI_TENANT_ID'
 else:
  found=_value(settings,('zeroui.fm1.governedTenantId','zeroui.canonicalWorkflow.tenantId','zeroui.tenantId','tenant_id','ZEROUI_TENANT_ID'))
  if found:tid,tid_source=found
  else:tid='';tid_source='database_unique_active_tenant'
 return {'tenant_db_url':db,'tenant_db_source':db_source,'tenant_id':tid,'tenant_id_source':tid_source,'repo_root':str(repo)}
