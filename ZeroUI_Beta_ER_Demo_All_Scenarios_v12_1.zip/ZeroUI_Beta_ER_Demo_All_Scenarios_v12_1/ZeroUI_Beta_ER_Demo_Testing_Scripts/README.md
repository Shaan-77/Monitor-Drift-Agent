# ZeroUI Beta ER Demo Testing Scripts — v12.1

This pack is repository-only. Policy values are dynamically loaded from tenant PostgreSQL on every run.

## Authority chain

active tenant
-> exactly one active runtime generation
-> exact ER member
-> pinned tenant_threshold_version_id
-> Published threshold version
-> effective relational values/config
-> governed rules

There are no hardcoded policy threshold values and no latest-published/local/default threshold fallback.

## First step in a new repository

Run the OS-specific `00-Prepare-DemoRepo` wrapper, or use the outer cross-platform launcher with `-Action Setup`, before running individual scenarios.

Prepare performs read-only policy validation and adds only the demo distribution/pack path to that repository's local Git exclude file. It does not modify the ZeroUI Extension or VSIX.

## Actions

Allow
- rolls package-owned demo evidence back ER-by-ER using the active DB policy;
- does not automatically rewrite unknown real application violations.

Warn
- dynamically examines active Beta ER policies;
- simulates WARN only where the active policy defines `human_review_required`;
- ERs without an active WARN lane are skipped;
- an active WARN lane without a safe deterministic repo simulator fails closed.

Block
- dynamically examines active Beta ER policies;
- simulates active `deny` lanes only;
- threshold crossings, regexes, file locations, dependency severity boundaries, test artifacts and effective values come from the DB;
- unsupported active hard-block semantics fail closed.

## Repository portability

The target repository is discovered with Git, not by a hardcoded path or repository name. The lifecycle supports repositories whose path contains spaces and uses `git rev-parse --git-path` for repository-internal state so Git worktrees are handled correctly.

The runtime configuration is read only from the current process or the target repository:
- `ZEROUI_TENANT_DB_URL`
- `ZEROUI_TENANT_ID` / `ZEROUI_DEMO_TENANT_ID`
- supported keys in `.vscode/settings.json`, `.cursor/settings.json`, or `.zeroui/runtime.json`

The PostgreSQL URL must resolve host, user and database (database in the URL path or `?dbname=`). `psql` is invoked with `-w`; bad or missing credentials fail closed instead of opening an interactive password prompt.

## Safety boundary

The pack does not modify/build/install/uninstall/reload the ZeroUI Extension or VSIX. The policy resolver performs no DB writes. The installed ZeroUI product remains authoritative for the final governed decision; run **Check Current Context** after simulation.
